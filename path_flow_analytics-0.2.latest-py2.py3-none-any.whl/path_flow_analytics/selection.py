# IBM Confidential

# OCO Source Materials

# 5747-SM3

# © Copyright IBM Corp. 2019

# The source code for this program is not published or otherwise divested of its trade secrets, irrespective of what has been depos-ited with the U.S. Copyright Office.

import pandas as pd
import numpy as np

def to_dataframe(selection):
    """convert selection tuples to dataframe
    """
    result = {}

    if len(selection["rerouted"]) == 0:
        result['rerouted'] = pd.DataFrame(columns=['conversation_id','log_id'], dtype='object')
    else:
        result['rerouted'] = pd.DataFrame({'conversation_id': np.array(list(zip(*selection["rerouted"]))[0]), 'log_id': np.array(list(zip(*selection["rerouted"]))[1])})

    if len(selection["dropped_off"]) == 0:
        result['dropped_off'] = pd.DataFrame(columns=['conversation_id','log_id'], dtype='object')
    else:
        result['dropped_off'] = pd.DataFrame({'conversation_id': np.array(list(zip(*selection["dropped_off"]))[0]), 'log_id': np.array(list(zip(*selection["dropped_off"]))[1])})
    #return pd.DataFrame({'conversation_id': np.array(list(zip(*selection))[0]), 'log_id': np.array(list(zip(*selection))[1])})
    return result

def extract_conversation_transcript(df_logs, selection_df, index):
    """extract conversation transcript from logs, based on selection df, and index of interest
    """
    selected_by_index = selection_df.iloc[index]
    transcript = df_logs[df_logs['conversation_id'] == selected_by_index['conversation_id']]
    transcript = transcript.sort_values(by='response_timestamp')
    transcript['you_are_here'] = ""
    transcript.loc[transcript['log_id'] == selected_by_index['log_id'], 'you_are_here'] = '--->'
    return transcript[['you_are_here','response_timestamp','request_text','response_text','log_id','conversation_id','nodes_visited', 'node_visited',
       'branch_exited', 'branch_exited_reason']]


def fetch_logs(logs_df, selection_df):
    """fetch all logs from conversations in selection_df
    """
    print("Deprecated.  Use fetch_logs_by_selection or fetch_logs_by_id")
    return logs_df[logs_df['conversation_id'].isin(list(selection_df['conversation_id']))]

def fetch_logs_by_selection(logs_df, selection_df):
    """fetch all logs from conversations in selection_df
    """
    return logs_df[logs_df['conversation_id'].isin(list(selection_df['conversation_id']))]
    
def fetch_logs_by_id(logs_df, conversation_id):
    """fetch logs by conversation id
    """
    return logs_df[logs_df['conversation_id'] == conversation_id] 