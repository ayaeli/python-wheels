# IBM Confidential

# OCO Source Materials

# 5747-SM3

# © Copyright IBM Corp. 2019

# The source code for this program is not published or otherwise divested of its trade secrets, irrespective of what has been depos-ited with the U.S. Copyright Office.

import sys
#import requests
from IPython.display import display, Javascript, HTML
import json
import datetime
import os
import os.path
import pkgutil

# this code will check if you're in the dev environment (assumption: you work in notebooks folder which is sibling to src)
def is_production():
    import subprocess
    import sys

    reqs = subprocess.check_output([sys.executable, '-m', 'pip', 'freeze'])
    installed_packages = [r.decode().split('==')[0] for r in reqs.split()]
    return 'path-flow-analytics' in installed_packages

#file_location_in_dev_mode = os.path.join(os.path.join(os.getcwd(),'src/conversation_analytics_toolkit/flowchart2.js'))

# determine if we're in dev-environment.  In dev environment we're checking for sub-directory of /notebooks
# cwd = os.getcwd()
# notebooks_folder_location = cwd.rfind("/notebooks")
# if (notebooks_folder_location == -1):
#     production_mode = True
# else:
#     production_mode = False
# project_folder = cwd[:notebooks_folder_location]

#file_location_in_dev_mode = os.path.join(project_folder, 'src/conversation_analytics_toolkit/flowchart2.js')
#flowchart_css = ""
#production_mode = False

#if os.path.isdir(project_folder):
#if production_mode == False:
if not is_production():
    cwd = os.getcwd()
    notebooks_folder_location = cwd.rfind("notebooks")
    project_folder = cwd[:notebooks_folder_location-1]
    print('dev-mode detected:' + project_folder)
    display(Javascript("require.config({paths: {d3: 'https://cdnjs.cloudflare.com/ajax/libs/d3/4.13.0/d3.min'}});"))
    display(Javascript(filename=os.path.join(project_folder, "src","conversation_analytics_toolkit", "flowchart2.js")))
    display(Javascript(filename=os.path.join(project_folder, "src","conversation_analytics_toolkit", "transcript.js")))
    display(Javascript(filename=os.path.join(project_folder, "src","conversation_analytics_toolkit", "wordpackchart.js")))   
    display(HTML(filename=os.path.join(project_folder, "src","conversation_analytics_toolkit", "flowchart.css.html")))
    display(HTML(filename=os.path.join(project_folder, "src","conversation_analytics_toolkit", "transcript.css.html")))
    display(HTML(filename=os.path.join(project_folder, "src","conversation_analytics_toolkit", "wordpackchart.css.html")))
else:
    #production_mode = True
    print('production-mode detected')
    flowchart_css = pkgutil.get_data(__package__, 'flowchart.css.min.html').decode('utf-8')
    flowchart_js = pkgutil.get_data(__package__, 'flowchart2.min.js').decode('utf-8')
    transcript_css = pkgutil.get_data(__package__, 'transcript.css.min.html').decode('utf-8')
    transcript_js = pkgutil.get_data(__package__, 'transcript.min.js').decode('utf-8')
    wordpackchart_css = pkgutil.get_data(__package__, 'wordpackchart.css.min.html').decode('utf-8')
    wordpackchart_js = pkgutil.get_data(__package__, 'wordpackchart.min.js').decode('utf-8')
    display(Javascript("require.config({paths: {d3: 'https://cdnjs.cloudflare.com/ajax/libs/d3/4.13.0/d3.min'}});"))
    display(Javascript(data=flowchart_js))
    display(Javascript(data=transcript_js))
    display(Javascript(data=wordpackchart_js))
    display(HTML(data=flowchart_css))
    display(HTML(data=transcript_css))
    display(HTML(data=wordpackchart_css))
def draw_flowchart(config, json_data, width=600, height=400):
    display(Javascript("""
        (function(element){
            require(['flowchart2'], function(flowchart2) {
                var config = %s;
                if (config["debugger"]===true){
                   debugger;
                };
                var chart = flowchart2(element.get(0), config, %s);

                chart.on("export",function(e){
                    var selection = JSON.stringify(e.selection).replace(/"/g , "'");
                    //var selection = JSON.stringify(e).replace(/"/g , "'");
                    IPython.notebook.kernel.execute("selection = " + selection);
                });
            });
        })(element);
    """ % (json.dumps(config), json.dumps(json_data))))

def convert_timestamp(item_date_object):
    if isinstance(item_date_object, (datetime.date, datetime.datetime)):
        return item_date_object.isoformat()

def draw_transcript(config, json_data, width=600, height=400):
    display(Javascript("""
        (function(element){
            require(['transcript'], function(transcript) {
                var config = %s;
                if (config["debugger"]===true){
                   debugger;
                };
                var chart = transcript(element.get(0), config, %s);
            });
        })(element);
    """ % (json.dumps(config), json.dumps(json_data, default=convert_timestamp))))
    
def draw_wordpackchart(config, json_data, width=600, height=400):
    display(Javascript("""
        (function(element){
            require(['wordpackchart'], function(wordpackchart) {
                var config = %s;
                if (config["debugger"]===true){
                   debugger;
                };
                var chart = wordpackchart(element.get(0), config, %s);
            });
        })(element);
    """ % (json.dumps(config), json.dumps(json_data, default=convert_timestamp))))