# IBM Confidential

# OCO Source Materials

# 5747-SM3

# © Copyright IBM Corp. 2019

# The source code for this program is not published or otherwise divested of its trade secrets, irrespective of what has been depos-ited with the U.S. Copyright Office.

import re

def _events_from_row(canonical_row):
    events_array=[]
    current_request = canonical_row["request_text"]
    current_response = canonical_row["response_text"]
    if current_request!="":
        event={}
        event["agent"]="user"
        event["type"]="request"
        event["timestamp"]=canonical_row["response_timestamp"]
        current_message={}
        current_message["text"]=current_request
        current_messages=[current_message]
        event["messages"]=current_messages
        if "highlight" in canonical_row:
            if canonical_row["highlight"] == True:
                event["highlight"] = True                   
        events_array.append(event)

    # create response object
    event={}
    event["agent"]="bot"
    event["type"]="response"
    event["timestamp"]=canonical_row["response_timestamp"]
    current_message={}
    current_message["text"]=current_response
    if "node_visited" in canonical_row:
        event["node_visited"] = canonical_row["node_visited"]        
    if "bot_response_buttons" in canonical_row:
        # temporary add buttons as 2nd 
        s = canonical_row["bot_response_buttons"]
#         s = s.replace(']','')
#         s = s.replace('[','')
#         s = s.replace("'",'')
        if s != '[]':
            current_message["buttons"] = s
    if "bot_response_action" in canonical_row:
        if canonical_row["bot_response_action"]=="Transfer":
            event["type"]="handoff"
        event["action"] = canonical_row["bot_response_action"]  
    current_messages=[current_message]
    event["messages"]=current_messages 
    events_array.append(event)

    return events_array        

def _add_insights_tags(existing_tags, canonical_row):
    if "insights_tags" in canonical_row:
        new_tags = canonical_row["insights_tags"]
        for new_tag in new_tags:
            if new_tag in existing_tags:
                existing_tags[new_tag]+=1
            else:
                existing_tags[new_tag]=1            

def to_transcript(df_canonical):
    dict_list=[]
    #df_canonical=df_canonical[["response_timestamp","node_visited","request_text","input_type","response_text",
    #                           "bot_response_action","resolution","reason",
    #                           "conversation_id"]].sort_values(by=["conversation_id", "response_timestamp"])
    df_canonical=df_canonical.sort_values(by=["conversation_id", "response_timestamp"])
    conversations=df_canonical.groupby("conversation_id")
    for name, group in conversations:
        current_dict={}
        current_conversation={}
        current_conversation["id"]=name
        current_dict["conversation"]=current_conversation
         
        conversation_events=[]
        insight_tags = {} # map of tags to their counts
        for row_index, row in group.iterrows():
            conversation_events.extend(_events_from_row(row))
            _add_insights_tags(insight_tags, row)
        current_dict["events"] = conversation_events
        current_dict["insight_tags"] = insight_tags
        dict_list.append(current_dict)
        
    return dict_list