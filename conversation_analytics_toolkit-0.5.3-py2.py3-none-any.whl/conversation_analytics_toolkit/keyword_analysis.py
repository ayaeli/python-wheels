# IBM Confidential

# OCO Source Materials

# 5747-SM3

# © Copyright IBM Corp. 2019

# The source code for this program is not published or otherwise divested of its trade secrets, irrespective of what has been depos-ited with the U.S. Copyright Office.


from nltk.corpus import words
 
#####################################################################
# Makes code work faster
WORD_SET=set(words.words())

import matplotlib.pyplot as plt

##############################################################
import re
import numpy as np
import pandas as pd
#######################################################################
# wordcloud
from wordcloud import WordCloud, STOPWORDS, ImageColorGenerator

#######################################################################
# sklearn
from sklearn.model_selection import train_test_split
from sklearn.utils import resample
from sklearn.feature_extraction.text import TfidfVectorizer 
from sklearn.metrics import accuracy_score
from sklearn.pipeline import Pipeline 
from sklearn.linear_model import SGDClassifier

################################################
from nltk.corpus import stopwords

#####################################################################
# Default option to produce weight for word clouds
def produce_weights(n):
    weights=[]
    w=1.0/n+1.0/(6.0*n)
    for i in range(0,n):       
        weights.append(w)
        w-=(1.0/(3.0*n))/(n-1)
    return(weights)

##################################################################################
# bar plot for two series
def plot_bar2(bar1,bar2,x_label,y_label,xtick_labels,xangle,bar_legend,title):
    
    plt.rcParams['figure.figsize'] = [15, 10]
    #plt.rcParams['figure.figsize'] = [18, 12]
    
    num_bars=len(bar1) 
     
    font = {'weight' : 'bold',
            'size'   : 14}

    plt.rc('font', **font)
    #plt.axis('on')
    
    fig = plt.figure()
    ax = fig.add_subplot(111)
    
    rects1 = ax.bar(np.arange(0.35,num_bars,1),bar1,width=0.3,color='red')
    rects2 = ax.bar(np.arange(0.65,num_bars,1),bar2,width=0.3,color='green')

    plt.xlabel(x_label,fontsize=16)
    plt.ylabel(y_label,fontsize=16)    
     
    plt.xticks(np.arange(0.5,num_bars,1),xtick_labels, rotation=xangle, ha='right')
        
    plt.xlim(0,num_bars)
        
    #plt.grid(axis='y')
    plt.grid()
    plt.title(title, fontsize=30, position=[0.5, 1.03]) 
    ax.legend( (rects1[0], rects2[0]), bar_legend)
    #plt.tight_layout()
    
    plt.show()   
    
    return

###############################################################################
# show two word clouds side by side
def show_word_cloud2(cloud_dict1,cloud_title1,cloud_dict2,cloud_title2):
    
    cloud_dict_new1={}
    cloud_dict_new2={}
    
    # replace spaces by underscore
    for key in cloud_dict1:
        key1 = key.replace(" ", "_")
        cloud_dict_new1[key1]=cloud_dict1[key]       
    
    # replace spaces by underscore
    for key in cloud_dict2:
        key2 = key.replace(" ", "_")
        cloud_dict_new2[key2]=cloud_dict2[key] 
    
    f1= lambda *args, **kwargs: (240,128,128) # lightcoral(255,0,0)
    f2= lambda *args, **kwargs: (30,144,255) # dodgerblue
    cloud1 = WordCloud(stopwords=STOPWORDS, collocations = False, relative_scaling=1, 
                         color_func=f1,
                          #max_words=30,  
                          background_color='lightgrey', prefer_horizontal=1, width=1200, height=1200
                         ).generate_from_frequencies(cloud_dict_new1,max_font_size=144)
    
    cloud2 = WordCloud(stopwords=STOPWORDS, collocations = False, relative_scaling=1, 
                          #max_words=30,  
                         color_func=f2,  
                          background_color='lightgrey', prefer_horizontal=1, width=1200, height=1200
                         ).generate_from_frequencies(cloud_dict_new2,max_font_size=144)
    
    plt.rcParams['figure.figsize'] = [14, 7]                    
    fig = plt.figure() 
    ax1 = fig.add_subplot(1,2,1)
    ax1.set_title(cloud_title1, size=20,  position=[0.5, 1.03]) # Title 
    ax1.imshow(cloud1)
    ax1.axis('off')
    ax2 = fig.add_subplot(1,2,2)
    ax2.set_title(cloud_title2, size=20,  position=[0.5, 1.03]) # Title 
    ax2.imshow(cloud2)
    ax2.axis('off')
    #     plt.imshow(cloud, interpolation='bilinear')
    return

##################################################################################

# bar plot for two series
def plot_frequencies(df_frequencies,title1,title2,legend1,legend2,num_bars,both=True):
    
    df_frequencies1 = df_frequencies.sort_values(by="Failure keywords: negative corpus frequencies, %", ascending=False)
    df_frequencies2 = df_frequencies.sort_values(by="Success keywords: positive corpus frequencies, %", ascending=False)
    
    bar1 = df_frequencies1["Failure keywords: negative corpus frequencies, %"][0:num_bars]
    bar2 = df_frequencies1["Failure keywords: positive corpus frequencies, %"][0:num_bars]
    bar3 = df_frequencies2["Success keywords: negative corpus frequencies, %"][0:num_bars]
    bar4 = df_frequencies2["Success keywords: positive corpus frequencies, %"][0:num_bars]       
    
    tick_labels1=df_frequencies1[title1]
    tick_labels2=df_frequencies2[title2]
    
    x_label="keywords"
    y_label="frequency, %"
    
    bar_legend = [legend1,legend2]
  
    if both: 
        
        plt.rcParams['figure.figsize'] = [16, 6]  
                    
        fig = plt.figure() 
        ax1 = fig.add_subplot(1,2,1)
        ax1.set_title(title1, size=20,  position=[0.5, 1.03]) # Title 
        ax1.set_xlabel(x_label,fontsize=14)
        ax1.set_ylabel(y_label,fontsize=14)  
        ax1.set_xticks(np.arange(0.5,num_bars,1)) 
        ax1.set_xticklabels(tick_labels1,fontsize=10,rotation=20,ha='right')
        ax1.set_xlim(0,num_bars)
        rects1 = ax1.bar(np.arange(0.35,num_bars,1),bar1,width=0.3,color='red')
        rects2 = ax1.bar(np.arange(0.65,num_bars,1),bar2,width=0.3,color='green')
        ax1.legend( (rects1[0], rects2[0]), bar_legend) 
        plt.grid()
        
        ax2 = fig.add_subplot(1,2,2)
        ax2.set_title(title2, size=20,  position=[0.5, 1.03]) # Title 
        ax2.set_xlabel(x_label,fontsize=14)
        ax2.set_ylabel(y_label,fontsize=14)
        ax2.set_xticks(np.arange(0.5,num_bars,1)) 
        ax2.set_xticklabels(tick_labels2, fontsize=10, rotation=20, ha='right')
        ax2.set_xlim(0,num_bars)
        rects3 = ax2.bar(np.arange(0.35,num_bars,1),bar3,width=0.3,color='red')
        rects4 = ax2.bar(np.arange(0.65,num_bars,1),bar4,width=0.3,color='green')
        ax2.legend( (rects3[0], rects4[0]), bar_legend) 
        
        plt.grid()
        
    else: 
        
        plt.rcParams['figure.figsize'] = [8, 6] 
        
        fig = plt.figure()
        ax = fig.add_subplot(111)
        
        rects1 = ax.bar(np.arange(0.35,num_bars,1),bar1,width=0.3,color='red')
        rects2 = ax.bar(np.arange(0.65,num_bars,1),bar2,width=0.3,color='green')
    
        plt.xlabel(x_label,fontsize=14)
        plt.ylabel(y_label,fontsize=14)    
         
        plt.xticks(np.arange(0.5,num_bars,1),tick_labels1, rotation=20, ha='right') 
        
        plt.xlim(0,num_bars)        
        
        plt.title(title1, fontsize=20, position=[0.5, 1.03]) 
        ax.legend( (rects1[0], rects2[0]), bar_legend) 
     
        plt.grid()
  
    plt.show()  
    
    return 


##############################################################
# returns clean string
def clean_text(text):     
    
    REPLACE_BY_SPACE_RE = re.compile('[/(){}\[\]\|@,;]')
    BAD_SYMBOLS_RE = re.compile('[^0-9a-z #+_]')
    REGULAR_STOPWORDS = set(stopwords.words('english'))
    
    # not a perfect mechanism
    CUSTOM_STOPWORDS={"like","would","tell","still","gone","want","get","said","wont","new","take","taken","see",
                      "says","say","saying","look","looking","one","made","make","back","put","go","going","went",
                      "yes","no","00","set","come","came","hi","hello","much","got","dont","de","none","thank"}
        
    STOPWORDS = REGULAR_STOPWORDS | CUSTOM_STOPWORDS
     
    text = text.lower() # lowercase text
    text = REPLACE_BY_SPACE_RE.sub(' ', text) # replace REPLACE_BY_SPACE_RE symbols by space in text
    text = BAD_SYMBOLS_RE.sub('', text) # delete symbols which are in BAD_SYMBOLS_RE from text
    text = ' '.join(word for word in text.split() if word not in STOPWORDS) # delete stopwors from text
    return text

##############################################################
# Get frequencies of most significant features
def get_frequency(text_corpus, text, percentage=True):
    num_text = len(text_corpus)
    if len(text.split())==1: # single word
        if percentage:
            return ((100*len([k for k in text_corpus if text in k.split()]))/num_text)       
        else:
            return len([k for k in text_corpus if text in k.split()])         
    else:
        if percentage:
            return ((100*len([k for k in text_corpus if text in k]))/num_text) 
        else:
            return len([k for k in text_corpus if text in k])
    
##########################################################################################################
def get_df_frequencies(text_negative, text_positive, neg_list, pos_list, table_title1, table_title2, percentage=True):
    neg_list_neg_freq=[]
    neg_list_pos_freq=[]
    pos_list_neg_freq=[]
    pos_list_pos_freq=[]
    
    num_negative=len(text_negative)
    num_positive=len(text_positive)
    num_features=len(neg_list)
    
    for i in range(0, num_features):
        if len(neg_list[i].split())==1: # single word
            if percentage:
                neg_list_neg_freq.append((100*len([k for k in text_negative if neg_list[i] in k.split()]))/num_negative)
                neg_list_pos_freq.append((100*len([k for k in text_positive if neg_list[i] in k.split()]))/num_positive)                
            else:
                counter1=len([k for k in text_negative if neg_list[i] in k.split()])
                neg_list_neg_freq.append(counter1)
                counter2=len([k for k in text_positive if neg_list[i] in k.split()])
                if counter2==0:
                    counter2=1                
                neg_list_pos_freq.append((counter1/counter2)*(num_positive/num_negative)*1.0)
        else:
            if percentage:
                neg_list_neg_freq.append((100*len([k for k in text_negative if neg_list[i] in k]))/num_negative)
                neg_list_pos_freq.append((100*len([k for k in text_positive if neg_list[i] in k]))/num_positive)
            else:
                counter1 = len([k for k in text_negative if neg_list[i] in k])
                neg_list_neg_freq.append(counter1)
                counter2 = len([k for k in text_positive if neg_list[i] in k])
                if counter2==0:
                    counter2=1 
                neg_list_pos_freq.append((counter1/counter2)*(num_positive/num_negative)*1.0) 
        
        if len(pos_list[i].split())==1: # single word
            if percentage:
                pos_list_pos_freq.append((100*len([k for k in text_positive if pos_list[i] in k.split()]))/num_positive)
                pos_list_neg_freq.append((100*len([k for k in text_negative if pos_list[i] in k.split()]))/num_negative)
            else:
                counter1 = len([k for k in text_positive if pos_list[i] in k.split()])
                pos_list_pos_freq.append(counter1)
                counter2 = len([k for k in text_negative if pos_list[i] in k.split()])
                if counter2==0:
                    counter2=1                 
                pos_list_neg_freq.append((counter1/counter2)*(num_negative/num_positive)*1.0)
        else:
            if percentage: 
                pos_list_pos_freq.append((100*len([k for k in text_positive if pos_list[i] in k]))/num_positive) 
                pos_list_neg_freq.append((100*len([k for k in text_negative if pos_list[i] in k]))/num_negative)                
            else:
                counter1 = len([k for k in text_positive if pos_list[i] in k])                             
                pos_list_pos_freq.append(counter1)
                counter2 = len([k for k in text_negative if pos_list[i] in k])
                if counter2==0:
                    counter2=1 
                pos_list_neg_freq.append((counter1/counter2)*(num_negative/num_positive)*1.0)
                
    df_frequencies = pd.DataFrame() 
    df_frequencies[table_title1] = neg_list 
    df_frequencies["Failure keywords: negative corpus frequencies, %"] = neg_list_neg_freq
    df_frequencies["Failure keywords: positive corpus frequencies, %"] = neg_list_pos_freq
    df_frequencies[table_title2] = pos_list
    df_frequencies["Success keywords: positive corpus frequencies, %"] = pos_list_pos_freq
    df_frequencies["Success keywords: negative corpus frequencies, %"] = pos_list_neg_freq

    return df_frequencies    

##########################################################################################
# Create training and testing sets
def create_test_train(text_positive, text_negative, clean, balance):
    
    PRINT_MODE=False
    
    if clean:
        text_positive = [clean_text(x) for x in text_positive]
        text_negative = [clean_text(x) for x in text_negative]
    
    num_positive=len(text_positive)
    num_negative=len(text_negative) 
    
    if balance=="truncate":
              
        if num_positive>num_negative:
            if PRINT_MODE:
                print("Truncate positive sample to get balanced data")
            sample = text_positive[0:num_negative] + text_negative
            outcome=["positive"] * num_negative + ["negative"] * num_negative

        elif num_positive<=num_negative:
            if PRINT_MODE:
                print("Truncate negative sample to get balanced data")
            sample = text_positive + text_negative[0:num_positive]
            outcome=["positive"] * num_positive+["negative"] * num_positive   
    
    elif balance=="resample":           
        
        if num_positive>num_negative:
            if PRINT_MODE:
                print("Resample negative sample to get balanced data")
            text_negative2 = resample(text_negative, replace=True, n_samples=num_positive-num_negative)
            #text_negative2 = random.sample(text_negative, num_positive-num_negative)
            sample = text_positive + text_negative + text_negative2
            outcome=["positive"] * num_positive+["negative"] * num_positive 
        # TODO : treat zero
        elif num_positive<=num_negative:
            if PRINT_MODE:
                print("Bootstrap positive sample to get balanced data")
            text_positive2 = resample(text_positive, replace=True, n_samples=num_negative-num_positive)
            sample = text_positive + text_positive2 + text_negative
            outcome=["positive"] * num_negative + ["negative"] * num_negative 
        
    
    text_train, text_test, outcome_train, outcome_test = train_test_split(sample, outcome, test_size=0.25, random_state = 20)
    
    if PRINT_MODE:
        print("Size of training set: "+str(len(text_train)))
        print("Size of testing set: "+str(len(text_test)))
    
    return text_train, text_test, outcome_train, outcome_test

########################################################################
def get_features(text_negative, text_positive, text_train, text_test, outcome_train, outcome_test, num_features, coeff_method):    
    
    # loss = hinge corresponds to linear SVM
    # penalty - regularization
    # alpha - related to regularization and learning rate 
    
    #no_shows=["account","number"]
    no_shows=[]
    
    ratio_parameter=2.0
     
    PRINT_MODE=False
    sgd = Pipeline([('vect_tfifd', TfidfVectorizer(ngram_range=(1, 2))), 
                    ('clf', SGDClassifier(loss='hinge', penalty='l2',alpha=1e-3, random_state=20,\
                                          max_iter=20, tol=None, fit_intercept=False)),])

    # fit model
    sgd_est = sgd.fit(text_train, outcome_train)

    outcome_pred = sgd.predict(text_test)
    
    if PRINT_MODE:
        print('accuracy %s' % accuracy_score(outcome_pred, outcome_test))
    
    feature_names = sgd_est.named_steps['vect_tfifd'].get_feature_names()
    feature_coeffs = sgd_est.named_steps['clf'].coef_[0]
 
    coeffs_with_features = sorted(zip(feature_coeffs, feature_names))
    
    ##############################
    # perform frequence check, print warnings
    counter_neg_features=0
    counter=0
    top_neg=[]
    while counter_neg_features<num_features:
        current_neg_feature=coeffs_with_features[counter][1] 
        get_neg_freq=get_frequency(text_negative,current_neg_feature)
        get_pos_freq=get_frequency(text_positive,current_neg_feature)
        
        if ratio_parameter*get_pos_freq>=get_neg_freq:
            if PRINT_MODE:
                print("Frequencies for negative feature "+current_neg_feature+" are not consistent. Feature is omitted")
                print("Negative frequency: "+str(get_neg_freq))
                print("Positive frequency: "+str(get_pos_freq))
        elif current_neg_feature not in no_shows:
            top_neg.append(coeffs_with_features[counter])
            counter_neg_features+=1
        
        counter+=1 
        
    counter_pos_features=0
    counter=0
    top_pos=[]
    while counter_pos_features<num_features:
        current_pos_feature=coeffs_with_features[-(counter+1)][1] 
        get_neg_freq=get_frequency(text_negative,current_pos_feature)
        get_pos_freq=get_frequency(text_positive,current_pos_feature)         
        
        if get_pos_freq<=ratio_parameter*get_neg_freq:
            if PRINT_MODE:
                print("Frequencies for positive feature '"+current_pos_feature+"' are not consistent. Feature is omitted.")
                print("Negative frequency: "+str(get_neg_freq))
                print("Positive frequency: "+str(get_pos_freq))
        elif current_pos_feature not in no_shows:            
            top_pos.append(coeffs_with_features[-(counter+1)])
            counter_pos_features+=1
        
        counter+=1    
        
    #top_neg = coeffs_with_features[0:num_features] 
    #top_pos = coeffs_with_features[:-(num_features + 1):-1]   
    neg_dict={} 
    pos_dict={}
    neg_list=[]
    pos_list=[]
    
    w=produce_weights(num_features)
    for i in range(0,num_features): 
        neg_list.append(top_neg[i][1])
        pos_list.append(top_pos[i][1])
        if coeff_method=="model":
            neg_dict[top_neg[i][1]] = -top_neg[i][0]
            pos_dict[top_pos[i][1]] = top_pos[i][0]
        elif coeff_method=="default":
#             print("Weights")
#             print(w)
            neg_dict[top_neg[i][1]] = w[i]
            pos_dict[top_pos[i][1]] = w[i]
    
    return neg_dict, pos_dict, neg_list, pos_list 

########################################################################
def keyword_clouds(text_negative, text_positive, num_features,cloud_title1,cloud_title2):
    do_cleaning = True
    balance_method="resample" # truncate is another
    
    text_train, text_test, outcome_train, outcome_test = create_test_train(text_positive, text_negative, do_cleaning, balance_method) 
     
    cloud_dict1, cloud_dict2, neg_list, pos_list =  get_features(text_negative, text_positive, text_train, text_test, outcome_train, outcome_test,num_features,"default")     
 
    show_word_cloud2(cloud_dict1,cloud_title1,cloud_dict2,cloud_title2)
    
    return

########################################################################
def keyword_bar_frequencies(text_negative, text_positive, num_bars, title1, title2, legend1, legend2, both=True):
     
    #############################################################################
    do_cleaning = True
    balance_method="resample" # truncate is another
    
    text_train, text_test, outcome_train, outcome_test = create_test_train(text_positive, text_negative, do_cleaning, balance_method) 
    
    # cloud_dict contains weights
    cloud_dict1, cloud_dict2, neg_list, pos_list =  get_features(text_negative, text_positive, text_train, text_test,\
                                                        outcome_train, outcome_test, num_bars, "default")  
    
    df_frequencies = get_df_frequencies(text_negative, text_positive, neg_list, pos_list, title1, title2) 
    
    #print(df_frequencies.head(n=25))
    
    plot_frequencies(df_frequencies,title1,title2,legend1,legend2,num_bars,both)
    
    return

########################################################################
def keyword_table_brief(text_negative, text_positive, num_keywords, title1, title2):
 #
    do_cleaning = True
    balance_method="resample" # truncate is another
    
    text_train, text_test, outcome_train, outcome_test = create_test_train(text_positive, text_negative, do_cleaning, balance_method) 
    
    cloud_dict1, cloud_dict2, neg_list, pos_list =  get_features(text_negative, text_positive, text_train, text_test,\
                                                        outcome_train, outcome_test, num_keywords, "default") 
   
    df_frequencies = get_df_frequencies(text_negative, text_positive, neg_list, pos_list, title1, title2) 
     
    return df_frequencies[[title1,title2]]

########################################################################
def keyword_table_detailed(text_negative, text_positive, num_keywords, title1, title2):
 #
    do_cleaning = True
    balance_method="resample" # truncate is another
    
    text_train, text_test, outcome_train, outcome_test = create_test_train(text_positive, text_negative, do_cleaning, balance_method) 
    
    cloud_dict1, cloud_dict2, neg_list, pos_list =  get_features(text_negative, text_positive, text_train, text_test,\
                                                        outcome_train, outcome_test, num_keywords, "default") 
   
    df_frequencies = get_df_frequencies(text_negative, text_positive, neg_list, pos_list, title1, title2, percentage=False) 
    
    df_frequencies.rename(columns={"Failure keywords: negative corpus frequencies, %": title1+": Frequency",\
                                   "Failure keywords: positive corpus frequencies, %": title1+": Power",\
                                   "Success keywords: positive corpus frequencies, %": title2+": Frequency",\
                                   "Success keywords: negative corpus frequencies, %": title2+": Power"}, inplace=True)
     
    return df_frequencies

#################################################################################################
def is_english(str):

    if len(str)<3:
        return False

    list_words=str.split()
    num_words=len(list_words)
    
    counter=0
    
    for i in range(0, num_words):
        current_word=list_words[i].lower()
        current_word=re.sub("[^a-zA-Z]+", "",current_word)
        if current_word in WORD_SET:
            counter+=1
    
    if (counter+0.0) / num_words >= 0.5:
        return True
    else:
        return False   

def clean_non_eng(utterances):
    utterances_clean=[]
    for item in utterances:
        if is_english(item):
            utterances_clean.append(item)
    return utterances_clean