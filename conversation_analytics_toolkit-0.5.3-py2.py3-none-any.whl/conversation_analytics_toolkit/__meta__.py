# Automatically created. Please do not edit.
__version__ = u'0.5.3'

__author__ = u'Avi Yaeli'
