from IPython.display import display, HTML
import pandas as pd
from numpy import nan
import time

class ChainFilter(): 
    def __init__(self, df, description="<<ALL-DATA>>"):
        self.df = df
        self.description = ""
        self.filters = []
        self._append_filter(self.df, "<<ALL-DATA>>", 0)
    def _append_filter(self, df, filter_name, duration_sec):       
        users = conversations = logs = timestamp_from = timestamp_to = nan
        if "conversation_id" in df.columns:
            conversations = len(df["conversation_id"].unique())
        if "log_id" in df.columns:
            logs = len(df["log_id"].unique())
        if "user_id" in df.columns:
            users = len(df["user_id"].unique())
        if len(df) > 0:
            if "response_timestamp" in df.columns:
                timestamp_from = min(df["response_timestamp"])
            if "response_timestamp" in df.columns:
                timestamp_to = max(df["response_timestamp"])
        self.filters.append({"filter_name": filter_name, 
                             "filter_duration_sec": duration_sec,
                             "rows":len(df), 
                             "users": users, 
                             "conversations": conversations,
                             "timestamp_from": timestamp_from,
                             "timestamp_to": timestamp_to,
                             "df": df})
        self.df = df
    def setDescription(self, description):
        self.description = description
        return self
    def printConversationFilters(self):
        display(HTML("<h1>" + self.description + "</h1>"))
        display(HTML(pd.DataFrame(self.filters)[["filter_name", "filter_duration_sec", "rows", "users", "conversations", "timestamp_from","timestamp_to"]].to_html()))
        return self
    def getDataFrame(self, i=-1):
        return self.filters[i]["df"]   
    def getLineageDetails(self, i=-1):
        if i == -1:
            i = len(self.filters)-1
        result = ""
        for j in range(0,i+1):
            if j >0:
                result+= " --> "
            result+= self.filters[j]["filter_name"] + "(" + str(self.filters[j]["conversations"]) + ")"
        return result             
    def by_dialog_node(self, dialog_node_id):
        """
        return the rows of conversations that include node_id in nodes_visited
        """
        now = time.time()
        filtered_df = self.df
        #find which rows include the dialog node
        rows = filtered_df[filtered_df.apply(lambda x: dialog_node_id in x["nodes_visited"], axis=1)]
        #find their conversation_id
        unique_conversations = rows["conversation_id"].unique()  
        #filter by conversation
        filtered_df = filtered_df[filtered_df.apply(lambda x: x["conversation_id"] in unique_conversations, axis=1)]
        later = time.time()
        duration_sec = int(later - now)
        self._append_filter(filtered_df, "by_dialog_node (" + dialog_node_id + ")", duration_sec)
        return self
    def by_node_name(self, node_name):
        """
        return the rows of conversations that include node in node_visited
        """
        now = time.time()
        filtered_df = self.df
        #find which rows include the dialog node
        rows = filtered_df[filtered_df.apply(lambda x: node_name in x["node_visited"], axis=1)]
        #find their conversation_id
        unique_conversations = rows["conversation_id"].unique()  
        #filter by conversation
        filtered_df = filtered_df[filtered_df.apply(lambda x: x["conversation_id"] in unique_conversations, axis=1)]
        later = time.time()
        duration_sec = int(later - now)
        self._append_filter(filtered_df, "by_node_name (" + node_name + ")", duration_sec)
        return self
    
    def from_node_onwards(self, node_name):
        """
        filter & trim conversations starting from node_id (in node_visited) 
        """
        now = time.time()
     
        # create an empty dataframe with the same column names and types
        filtered_df = pd.DataFrame(data=None, columns=self.df.columns)
        for column in filtered_df.columns:
            filtered_df[column] = filtered_df[column].astype(self.df[column].dtypes.name)
        df_by_conversation_id = self.df.groupby(by="conversation_id")
        #df_by_conversation_id = filtered_df.sort_values(by=["response_timestamp"]).groupby(by="conversation_id")
        for conversation_id, conversation_df in df_by_conversation_id:
            i=0
            conversation_df = conversation_df.sort_values(by=["response_timestamp"])
            for index, row in conversation_df.iterrows():
                i=i+1
                node_visited = row["node_visited"]
                if node_name == node_visited:
                    num_of_elements_to_copy = len(conversation_df)-i+1
                    filtered_df = pd.concat([filtered_df,conversation_df.tail(num_of_elements_to_copy)])
                    break
        later = time.time()
        duration_sec = int(later - now)
        self._append_filter(filtered_df, "from_node_onwards (" + node_name + ")", duration_sec)
        return self
    def by_date_range(self, start_date, end_date):
        now = time.time()        
        mask = (self.df['response_timestamp'] >= start_date) & (self.df['response_timestamp'] <= end_date)
        filtered_df = self.df.loc[mask]
        later = time.time()
        duration_sec = int(later - now)
        self._append_filter(filtered_df, "by_date_range (" + str(start_date) + ", " + str(end_date) + ")", duration_sec)
        return self
