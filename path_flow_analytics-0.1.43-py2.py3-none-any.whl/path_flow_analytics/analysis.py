from collections import defaultdict
import pandas as pd
import numpy as np
import json

# TBD - POTENTIALLY DEAD CODE
# class conversationPathAnalysis:
#     def __init__(self, config):
#         self.config = config
#         self.nodes_paths = defaultdict(list)
#
#     def handle_node_row(self, path, row, step, conv_id, log_id, is_conversation_start):
#         if not path in self.nodes_paths:
#             self.nodes_paths[path] = {"flows":0, "exits":0, "type": "NODE", "name": row.node_visited,"is_conversation_start": is_conversation_start, "conversation_log_ids":[]}
#         self.nodes_paths[path]["flows"] += 1
#
#     def handle_conversation_node_exit(self, path, step, conv_id, log_id):
#             self.nodes_paths[path]["exits"] += 1
#             self.nodes_paths[path]["conversation_log_ids"].append((conv_id, log_id))
#
#     def handle_conversation_path(self, df):
#         prev_node_path = ""
#         prev_row = ""
#         delimiter = "\\"
#         for i, (index, row) in enumerate(df.iterrows()):
#             node_code = row.node_visited
#             node_id = str(node_code)
#             if i==0:
#                 curr_node_path = node_id
#                 self.handle_node_row(curr_node_path, row, i, row.conversation_id, row.log_id, True)
#             else:
#                 curr_node_path = prev_node_path + delimiter + node_id
#                 if (i <= self.config["max_path_limit"]):
#                     self.handle_node_row(curr_node_path, row, i, row.conversation_id, row.log_id, False)
#                 else:
#                     print("reached depth limit, ignoring row " + str(i))
#                     self.handle_conversation_node_exit(prev_node_path, i-1, row.conversation_id, row.log_id)
#                     break
#             prev_node_path = curr_node_path
#             prev_row = row
#             if i == len(df) - 1:
#                 self.handle_conversation_node_exit(curr_node_path, i, row.conversation_id, row.log_id)
#
# def compute_flows(df, config):
#
#     # check optional config attributes
#     if "max_path_limit" not in config:
#         print ("Warning, max_path_limit is missing from config.  Default 50 is assumed")
#         config["max_path_limit"] = 50
#
#     # check mandatory dataframe fields
#     mandatory_columns = ['conversation_id', 'node_visited', 'Date']
#     for column in mandatory_columns:
#         if column not in df.columns.values:
#             raise Exception("input data is missing mandatory column: " + column)
#
#     analysis = conversationPathAnalysis(config)
#     for idx, conversation_df in df.groupby(df['conversation_id']):
#         conversation_df = conversation_df.sort_values(config["date_field"])
#         analysis.handle_conversation_path(conversation_df)
#
#     df_node_out = pd.DataFrame.from_dict(analysis.nodes_paths, orient="index")
#     df_node_out.reset_index(inplace=True)
#     df_node_out.rename(columns={'index':'path'}, inplace=True)
#     return pd.concat([df_node_out])[['path','name','type','is_conversation_start','flows','exits','conversation_log_ids']]

# TBD - CHECK IF THIS IS DEAD CODE
# class _conversationPathAnalysis:
#     def __init__(self, config):
#         self.config = config
#         self.nodes_paths = defaultdict(list)
#
#     def handle_node_row(self, path, row, step, conv_id, doc_id, is_conversation_start):
#         if not path in self.nodes_paths:
#             self.nodes_paths[path] = {"flows":0, "exits":0, "type": "NODE", "name": row.node_visited,"is_conversation_start": is_conversation_start, "conversation_log_ids":[]}
#         self.nodes_paths[path]["flows"] += 1
#
#     def handle_conversation_node_exit(self, path, step, conv_id, doc_id, response_branch_exited, response_branch_exited_reason, digression):
#         if (response_branch_exited==True and response_branch_exited_reason=='fallback' and digression is not True):
#             self.nodes_paths[path]["exits"] += 1
#             self.nodes_paths[path]["conversation_log_ids"].append((conv_id, doc_id))
#
#     def handle_conversation_path(self, df):
#         prev_node_path = ""
#         prev_row = ""
#         delimiter = "\\"
#         for i, (index, row) in enumerate(df.iterrows()):
#             node_code = row.node_visited
#             node_id = str(node_code)
#             if i==0:
#                 curr_node_path = node_id
#                 self.handle_node_row(curr_node_path, row, i, row.conversation_id, row.log_id, True)
#             else:
#                 curr_node_path = prev_node_path + delimiter + node_id
#                 if (i <= self.config["max_path_limit"]):
#                     self.handle_node_row(curr_node_path, row, i, row.conversation_id, row.log_id, False)
#                 else:
#                     print("reached depth limit, ignoring row " + str(i))
#                     self.handle_conversation_node_exit(prev_node_path, i-1, row.conversation_id, row.log_id, row.response_branch_exited, row.response_branch_exited_reason, row.digression)
#                     break
#             prev_node_path = curr_node_path
#             prev_row = row
#             if i == len(df) - 1:
#                 self.handle_conversation_node_exit(curr_node_path, i, row.conversation_id, row.log_id, row.response_branch_exited, row.response_branch_exited_reason, row.digression)
#
# def _compute_flows(df, config):
#
#     # check optional config attributes
#     if "max_path_limit" not in config:
#         print ("Warning, max_path_limit is missing from config.  Default 50 is assumed")
#         config["max_path_limit"] = 50
#
#     # check mandatory dataframe fields
#     mandatory_columns = ['conversation_id', 'node_visited', 'Date']
#     for column in mandatory_columns:
#         if column not in df.columns.values:
#             raise Exception("input data is missing mandatory column: " + column)
#
#     analysis = _conversationPathAnalysis(config)
#     for idx, conversation_df in df.groupby(df['conversation_id']):
#         conversation_df = conversation_df.sort_values(config["date_field"])
#         analysis.handle_conversation_path(conversation_df)
#
#     df_node_out = pd.DataFrame.from_dict(analysis.nodes_paths, orient="index")
#     df_node_out.reset_index(inplace=True)
#     df_node_out.rename(columns={'index':'path'}, inplace=True)
#     return pd.concat([df_node_out])[['path','name','type','is_conversation_start','flows','exits','conversation_log_ids']]


class _conversationPathAnalysis:
    def __init__(self, config):
        self.config = config
        self.nodes_paths = defaultdict(list)

    def handle_node_row(self, path, row, step, is_conversation_start, path_length):
        if not path in self.nodes_paths:
            self.nodes_paths[path] = {"flows":0, "rerouted":0, "dropped_off":0, "type": "NODE", "name": row.node_visited,"is_conversation_start": is_conversation_start, "conversation_log_ids_dropped_off":[], "conversation_log_ids_rerouted":[],"path_length": path_length}
        self.nodes_paths[path]["flows"] += 1
        #if (row.response_branch_exited==True and row.response_branch_exited_reason=='fallback' and row.digression is not True):
        if (row.branch_exited==True and row.branch_exited_reason=='fallback' and row.digression is False):
            self.nodes_paths[path]["rerouted"] += 1
            self.nodes_paths[path]["conversation_log_ids_rerouted"].append((row.conversation_id, row.log_id))
            return 'rerouted'

    def handle_conversation_node_exit(self, path, step, row):
        self.nodes_paths[path]["dropped_off"] += 1
        self.nodes_paths[path]["conversation_log_ids_dropped_off"].append((row.conversation_id, row.log_id))

    def handle_conversation_path(self, df):
        # workaround since I found that the canonical model isn't set right
        if 'digression' not in df.columns:
            df["digression"] = False

        prev_node_path = ""
        prev_row = ""
        delimiter = "\\"
        for i, (index, row) in enumerate(df.iterrows()):
            node_code = row.node_visited
            node_id = str(node_code)
            if i==0:
                curr_node_path = node_id
                path_length = 0
                if self.handle_node_row(curr_node_path, row, i, True, path_length) == 'rerouted':
                    break
            else:
                curr_node_path = prev_node_path + delimiter + node_id
                path_length += 1
                if (i <= self.config["max_path_limit"]):
                    if self.handle_node_row(curr_node_path, row, i, True, path_length) == 'rerouted':
                        break
                else:
                    print("reached depth limit, ignoring row " + str(i))
                    self.handle_conversation_node_exit(prev_node_path, i-1, row)
                    break
            prev_node_path = curr_node_path
            prev_row = row
            if i == len(df) - 1:
                self.handle_conversation_node_exit(curr_node_path, i, row)

def compute_flows(df, config):

    # check optional config attributes
    if "max_path_limit" not in config:
        print ("Warning, max_path_limit is missing from config.  Default 50 is assumed")
        config["max_path_limit"] = 50

    # check mandatory dataframe fields
    mandatory_columns = ['conversation_id', 'node_visited', 'Date']
    for column in mandatory_columns:
        if column not in df.columns.values:
            raise Exception("input data is missing mandatory column: " + column)

    analysis = _conversationPathAnalysis(config)
    for idx, conversation_df in df.groupby(df['conversation_id']):
        conversation_df = conversation_df.sort_values(config["date_field"])
        analysis.handle_conversation_path(conversation_df)

    df_node_out = pd.DataFrame.from_dict(analysis.nodes_paths, orient="index")
    df_node_out.reset_index(inplace=True)
    df_node_out.rename(columns={'index':'path'}, inplace=True)

    return pd.concat([df_node_out])[['path','name','type','is_conversation_start','flows','rerouted','dropped_off','conversation_log_ids_rerouted','conversation_log_ids_dropped_off','path_length']]
