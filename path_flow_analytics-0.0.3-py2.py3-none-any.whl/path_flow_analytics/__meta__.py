# Automatically created. Please do not edit.
__version__ = u'0.0.3'
__author__ = u'Lior Turgeman'
