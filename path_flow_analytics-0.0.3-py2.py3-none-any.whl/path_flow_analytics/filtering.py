import pandas as pd
import numpy as np

#filter logs by included node
def filter_logs_df_by_included_node(df, node, ConvDict):
    filtered_df_logs = None
    for i, (k, v) in enumerate(ConvDict.items()):
        dfP1=pd.DataFrame(v, columns=v.columns).sort_values(by=['response_timestamp'])
        if any(dfP1['node_visited'] == node):
            filtered_df_logs = pd.concat([filtered_df_logs,dfP1])

    return filtered_df_logs

## filter conversations starting with initial intent
def filter_logs_df_by_initial_intent(df, intent, ConvDict):
    filtered_df_logs = None
    for i, (k, v) in enumerate(ConvDict.items()):
        dfP1=pd.DataFrame(v, columns=v.columns).sort_values(by=['response_timestamp'])
        if (dfP1['response_intent'].iloc[0] == intent):
            filtered_df_logs = pd.concat([filtered_df_logs,dfP1])

    return filtered_df_logs