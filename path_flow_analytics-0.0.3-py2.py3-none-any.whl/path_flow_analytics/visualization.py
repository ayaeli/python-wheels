import sys
import requests
from IPython.display import display, Javascript, HTML
import json

import os
import os.path
import pkgutil

# this code will check if you're in the dev environment (assumption: you work in notebook folder which is sibling to src)

file_location_in_dev_mode = os.path.join(os.path.join(os.getcwd(),'src/path_flow_analytics/flowchart2.js'))
if os.path.isfile(file_location_in_dev_mode):
    print('dev-mode detected:')
    display(Javascript("require.config({paths: {d3: 'https://cdnjs.cloudflare.com/ajax/libs/d3/4.13.0/d3.min'}});"))
    display(Javascript(filename="flowchart2.js"))
    display(HTML(filename="flowchart.css.html"))
else:
    print('production-mode detected')
    flowchart_css = pkgutil.get_data(__package__, 'flowchart.css.html')
    flowchart_js = pkgutil.get_data(__package__, 'flowchart2.js')
    display(Javascript("require.config({paths: {d3: 'https://cdnjs.cloudflare.com/ajax/libs/d3/4.13.0/d3.min'}});"))
    display(Javascript(data=flowchart_css))
    display(HTML(data=flowchart_css))

def draw_flowchart_2(config, json_data, width=600, height=400):
    display(Javascript("""
        (function(element){
            require(['flowchart2'], function(flowchart2) {
                debugger;
                var chart = flowchart2(element.get(0), %s, %s);

                chart.on("export",function(e){
                    debugger;
                    var selection = JSON.stringify(e.selection).replace(/"/g , "'");
                    IPython.notebook.kernel.execute("selection = " + selection);
                });
                debugger;
            });
        })(element);
    """ % (json.dumps(config), json.dumps(json_data))))
