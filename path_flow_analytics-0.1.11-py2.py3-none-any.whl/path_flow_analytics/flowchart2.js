/**
 * Licensed Materials - Property of IBM
 *
 * 5747-C31, 5747-C32
 *
 * © Copyright IBM Corp. 2016  All Rights Reserved
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */


// flowChart2 supports a JSON Array Interface
require.undef('flowchart2');

define('flowchart2', ['d3'], function (d3) {
 debugger;
 //alert("hi flowchart5");
 //function draw(container, data, width, height) {
 function draw(container, config, data){
   //debugger;




    if (config["debugger"]===true){
      debugger;
    }

    var width = 0, height = 0;
    var _tooltip = null;
    var _config = {}, _chart = {}, _data = null;
    var self = this;

    var defaultConfig = {
        margin : {top: 20, right: 90, bottom: 30, left: 120},
        width : 2000,
        height : 600,
        nodeRadius : 10,
        linkWidth : 360,
        exitRatioThreshold: 0.0009,
        notHandledRatioThreshold: 0.30,
        sortByAttribute: "flowRatio",
        skillIntentMode: false,
        commonRootPathName: "Session Start", // will create a root node by this name (only works for json_array)
        maxChildrenInNode: 5,
        dataModel : "json_array" // "json" or "csv"
    };

    var _container = container;

    _config = $.extend(true, defaultConfig, config); // merge the default with the incoming config.
    //if (_config.dataModel == "json")
    var target = Array.isArray(data) ? [] : {};
    _data = $.extend(true, target, data); // make a copy of the data so we can update it

    _chart.container = _container;
    _chart.config = _config;
    _chart.selectedNode = {};
    createToolBar(_chart);

      // Set the dimensions and margins of the diagram
      var margin = _config.margin,
          width = _config.width - _config.margin.left - _config.margin.right,
          height = _config.height - _config.margin.top - _config.margin.bottom;

      //d3.select(_container[0]).selectAll("*").remove();

      //var svg = d3.select(_container[0]).append("svg")
      var svg = d3.select(_container).append("svg")
          .attr("class", "botvis flowchart")
          .attr("width", "95%")
          //.attr("width", width + margin.right + margin.left)
          .attr("height", height + _config.margin.top + _config.margin.bottom);

      _chart.svg = svg;

      var g = svg.append("g")
          .attr("transform", "translate("
                //+ _config.margin.left + "," + _config.margin.top + ")");
                + _config.margin.left + "," + _config.height/2 + ")");

      _tooltip = d3.select("body").append("div")
        .attr("class", "botvis-tooltip")
        .attr('pointer-events', 'none')
        .style("opacity", 0)
        .style("visibility", "hidden");

      var i = 0,
        duration = 750,
        root;

      // declares a tree layout and assigns the size
      //var treemap = d3.tree().size([height, width]);
      var treemap = d3.tree().nodeSize([70,700]);

      // Assigns parent, children, height, depth
      if (_config.dataModel == "d3_hierarchy") {
        if ("stratify" in _config)
          root = _config.stratify(_data);
        else
          throw "Stratify function is not defined for d3_hierarchy data model";
      } else if (_config.dataModel == "json")
        root = d3.hierarchy(_data, function(d) {
          return d.children;
        });
      else {
        if (_config.dataModel == "csv") {
          _data = d3.csvParse(_data);

        } else if (!(_config.dataModel == "json_array")) {
          throw "data model not supported,  use json, csv and json_array";
        }
        var stratify = d3.stratify()
            .parentId(function (d) {
                //console.log("path:" + d.path);
                return d.path.substring(0, d.path.lastIndexOf("\\"));
            })
            .id(function (d) {
                return d.path;
            });
        root = stratifyJSONArray(_data);
        //root = stratify(_data);
      }

      root.x0 = height / 2;
      root.y0 = 0;

      // sort all nodes in the tree
      root.each(function(node) {
          if (node.children) {
            node.children = node.children.sort(function(a,b) {
              var result = b.data[_config.sortByAttribute] - a.data[_config.sortByAttribute];
              return result;
            });
          }
      });

      // replace too long children with other nodes
      root.each(function(node) {
          if (node.children) {
            if (node.children.length > _config.maxChildrenInNode) {
              var topChildren = node.children.slice(0,_config.maxChildrenInNode);
              var otherChildren = node.children.slice(_config.maxChildrenInNode);

              var otherData = {
                dropoffs: 0,
                rerouted: 0,
                flowRatio: 0,
                flows: 0,
                id: "other",
                is_new_skill: 0,
                is_session_start: 0,
                name: "a few other",
                notHandledRatio: 0,
                not_handled: 0,
                path: "other",
                type: "other"
              };
              var otherNode = {
                  children: null,
                  _otherChildren: otherChildren,
                  data : otherData,
                  depth : node.depth + 1,
                  height: 0,
                  id: "other" + node.id,
                  parent: node
              }
              // compute othernode summary from children
              otherChildren.forEach(function(node) {otherNode.data.flows += node.data.flows;});
              var num_of_otherChildren = 0;
              otherChildren.forEach(function(node) {num_of_otherChildren += node.data.flows;});
              otherNode.data.flowRatio = otherNode.data.flows / root.data.flows;
              otherData.name = num_of_otherChildren + " others ...";

              topChildren.push(otherNode);
              node.children = topChildren;
            }
          }
        });

      // Collapse after the second level
      root.children.forEach(collapse);

      update(root);

      // Collapse the node and all it's children
      function collapse(d) {
        if(d.children) {
          d._children = d.children
          d._children.forEach(collapse)
          d.children = null
        }
      }

      function update(source) {

        // Assigns the x and y position for the nodes
        var treeData = treemap(root);

        // Compute the new tree layout.
        var nodes = treeData.descendants(),
            links = treeData.descendants().slice(1);

        // Normalize for fixed-depth.
        nodes.forEach(function(d){ d.y = d.depth * _config.linkWidth});

        // ****************** Nodes section ***************************

        // Update the nodes...
        //var node = svg.selectAll('g.node')
        var node = g.selectAll('g.node-group')
            .data(nodes, function(d) {return d.id || (d.id = ++i); });

        // Enter any new modes at the parent's previous position.
        var nodeEnter = node.enter().append('g')
            //.attr('class', 'node')
            .attr('class', 'node-group')
            .attr("transform", function(d) {
              return "translate(" + source.y0 + "," + source.x0 + ")";
          });
          //.on('click', click);

        // Add rect for the nodes
        var nodeObjects = nodeEnter.append('rect')
            .attr('class', function(d) {
              // if d is root, set class to rootnode, else node
              if (d.parent == null)
                return 'rootnode node';
              else if (d.data.type == "other")
                return 'node other-node';
              else
                return 'node';
            })
            .style("fill", function(d) {
                return d.data.notHandledRatio >= _config["notHandledRatioThreshold"] ? "#fb9a99" : "#00B4A0";
            }).style("stroke", function(d) {
                return d.data.notHandledRatio >= _config["notHandledRatioThreshold"] ? "#fb9a99" : "#00B4A0";
            }).on('click', click);



        nodeObjects.on("mouseover", function(d) {
            //debugger;
            _tooltip.transition()
             .duration(100)
             .style("opacity", .9)
             .style("visibility", "visible");

           var nodeNameLabel = "Name";
           var skillRow = "";
           if (_config.skillIntentMode) {
             nodeNameLabel = "Intent";
             skillRow = '<p><strong>Skill: </strong>' + d.data.skill + '<br>'
           }


           _tooltip.html(
                '<div>' +
                '<p><strong>' + nodeNameLabel + ': </strong>' + d.data.name +
                '<br>' +
                skillRow +
                '<strong>Messages: </strong>' + d.data.flows + " (" + (d.data.flowRatio*100).toFixed(1) + " %)" +
                '<br>' +
                '<strong>Dropped off: </strong>' + d.data.dropped_off + " (" + (d.data.dropped_offRatio*100).toFixed(1) + ' %)' +
                '<br>' +
                '<strong>Rerouted: </strong>' + d.data.rerouted + " (" + (d.data.reroutedRatio*100).toFixed(1) + ' %)' +
                '<br>' +
                '</p></div>')
             .style("left", (d3.event.pageX + 20) + "px")
             .style("top", (d3.event.pageY - 38) + "px");
          }).on("mouseout", function(d) {
            _tooltip.style("visibility", "hidden");
            _tooltip.style("opacity", 0);
          }).on("mousemove", function(d) {
            _tooltip.transition()
              .duration(0)
              .style("opacity", .9)
              .style("visibility", "visible")
              .style("left", (d3.event.pageX + 40) + "px")
              .style("top", (d3.event.pageY - 38) + "px");
          });
        // add the left twisty mark
        nodeEnter.append('rect')
            .attr('class', 'node-left-twisty')
            .attr('transform', 'translate(-30, 0)')
            .style("fill", function(d) {
                return d.data.notHandledRatio >= _config["notHandledRatioThreshold"] ? "#fb9a99" : "#00B4A0";
            })
            .style("stroke", function(d) {
                return d.data.notHandledRatio >= _config["notHandledRatioThreshold"] ? "#fb9a99" : "#00B4A0";
            });

        // add icon for the nodes
        nodeEnter.append('image')
        .attr('class', 'node-image')
        .attr('cursor', 'pointer')
        .style('pointer-events', 'none')
        .attr('href', function(d) {
          //var imagePath = "assets/img/botvis/";
          var imagePath = "/images/";
          return d.data.notHandledRatio >= _config["notHandledRatioThreshold"] ? imagePath + "not_handled2.svg" : imagePath + "handled2.svg";
        });

        // add the plus sign for children
        nodeEnter.append('text')
            .attr('class', 'node-label-num-children')
            .attr('transform', 'translate(190, -5)')
            .text(function(d) {
              return "+" + d.height;
            })
            .style("opacity", function(d) {
                // if has children which are not collapsed
                var hasHiddenChildren = (d.hasOwnProperty("children") && (d.children != null) && (d.children.length > 0));
                return hasHiddenChildren ? 1 : 0;

            });

        // add the skill name whenever there's a skill transition
        nodeEnter.append('text')
            .attr('class', 'node-label-new-skill')
            .attr('transform', 'translate(-25, -20)')
            .text(function(d) {
              return d.data.skill;
            })
            .style("opacity", function(d) {
                return (d.data.is_new_skill == 1)? 1 : 0;
            });

        // add the node exit path mark
        nodeEnter.append('path')
            .attr('class', 'node-exit-path')
            .attr('d', 'm0,0 Q30,0 30,30')
            .attr('transform', 'translate(190, 0)')
            .attr('opacity', function(d) {
                return d.data.dropped_offRatio + d.data.reroutedRatio > _config["exitRatioThreshold"] ? 0.5 : 0;
            })
            .style("stroke", function(d) {
                return d.data.dropped_offRatio + d.data.reroutedRatio > _config["exitRatioThreshold"] ? "#fb9a99" : "#7fc97f";
            })
            .style("stroke-width", function(d) {
                return (d.data.dropped_offRatio + d.data.reroutedRatio) * 10 ;
            });

        // Add labels for the nodes
        nodeEnter.append('text')
            .attr('class', 'node-label')
            .attr("dy", ".35em")
            .attr("x", function(d) {
                return 0;
            })
            .attr('cursor', 'pointer')
            .style('pointer-events', 'none')
            .text(function(d) { return d.data.name; });

        // Add labels for the incoming flow
        nodeEnter.append('text')
            .attr('class', 'node-flow-label')
            .attr("dy", ".35em")
            .attr("x", function(d) {
                return -70;
            })
            .attr("text-anchor", function(d) {
                //return d.children || d._children ? "end" : "start";
                return "middle"
            })
            .text(function(d) {
                var flows = d.data.flows;
                var flowsRatio = d.data.flowRatio;
                var text = (flowsRatio*100).toFixed(0) +  "% (" + flows + ")";
                return text;
                // var percentage = d.data.flowRatio * 100;
                // return (percentage.toFixed(1) + ' %');
            });

        // Add background for the node exit labels
        nodeEnter.append('rect')
            .attr('class', 'node-exit-label-background')
            .attr('opacity', function(d) {
                return d.data.dropped_offRatio + d.data.reroutedRatio > _config["exitRatioThreshold"] ? 0.4 : 0;
            })
            .attr("x", function(d) {
                return -10+50;
            })
            .attr("rx", 3)
            .attr("ry", 3)
            .attr("width", 55)
            .attr("height", 20);

        // Add labels for the node exit labels
        nodeEnter.append('text')
            .attr('class', 'node-exit-label')
            .attr("dy", ".35em")
            .attr('transform', 'translate(240, 40)')
            .attr('cursor', 'pointer')
            .attr('opacity', function(d) {
                return d.data.dropped_offRatio + d.data.reroutedRatio > _config["exitRatioThreshold"] ? 1 : 0;
            })
            .attr("x", function(d) {
                return -10;
            })
            .attr("text-anchor", function(d) {
                //return d.children || d._children ? "end" : "start";
                return "middle"
            })
            .text(function(d) {
              var exits = d.data.dropped_off + d.data.rerouted;
              var exitsRatio = d.data.dropped_offRatio + d.data.reroutedRatio;
              var text = (exitsRatio*100).toFixed(0) +  "% (" + exits + ")";
              return text
              // var percentage = d.data.dropped_offRatio + d.data.reroutedRatio * 100;
              // return (percentage.toFixed(1) + ' %');
            })
            .on('click', function(d){
              //debugger;
              console.log(_chart);
              //alert("copied path: " + d.data.path + " to memory");
              $(".botvis.flowchart.selection")[0].innerText ="Selection: " + d.data.name;
              $(".botvis.flowchart.selection-instruction")[0].innerText ="Click on export button to copy to notebook";
              _chart.selectedNode = d.data;
            });

        // UPDATE
        var nodeUpdate = nodeEnter.merge(node);

        // Transition to the proper position for the node
        nodeUpdate.transition()
          .duration(duration)
          .attr("transform", function(d) {
              return "translate(" + d.y + "," + d.x + ")";
           });

        // Update the node attributes and style
        nodeUpdate.select('rect.node')
          .style("fill", function(d) {
            return d.data.notHandledRatio >= _config["notHandledRatioThreshold"] ? "#fb9a99" : "#00B4A0";
          })
          .attr("x", -30)
          .attr("y", -15)
          .attr("rx", 14)
          .attr("ry", 14)
          .attr("width", 220)
          .attr("height", 30)
          .attr('cursor', 'pointer');

        // Update the plus
        nodeUpdate.selectAll('.node-label-num-children')
            .style("opacity", function(d) {
                // if has children which are not collapsed
                var hasHiddenChildren = (d.hasOwnProperty("children") && (d.children != null) && (d.children.length > 0));
                return hasHiddenChildren ? 0 : 1;
            });

        // Remove any exiting nodes
        var nodeExit = node.exit().transition()
            .duration(duration)
            .attr("transform", function(d) {
                return "translate(" + source.y + "," + source.x + ")";
            })
            .remove();

        // On exit reduce the node circles size to 0
        nodeExit.select('rect')
          .style('fill-opacity', 1e-6);

        // On exit reduce the opacity of text labels
        nodeExit.select('text')
          .style('fill-opacity', 1e-6);

        // ****************** links section ***************************

        // Update the links...
        //var link = svg.selectAll('path.flow-path')
        var link = g.selectAll('path.flow-path')
            .data(links, function(d) { return d.id; });

        // Enter any new links at the parent's previous position.
        var linkEnter = link.enter().insert('path', "g")
            .attr("class", "flow-path")
            .attr('d', function(d){
              var o = {x: source.x0, y: source.y0}
              return diagonal(o, o)
            });

        // UPDATE
        var linkUpdate = linkEnter.merge(link);

        // Transition back to the parent element position
        linkUpdate.transition()
            .duration(duration)
            .attr('d', function(d){ return diagonal(d, d.parent) })
            .attr('stroke-width', function(d){
              var strokeWidth = d.data.flowRatio * 40
              return strokeWidth > 1 ? strokeWidth : 1;
            });

        // Remove any exiting links
        var linkExit = link.exit().transition()
            .duration(duration)
            .attr('d', function(d) {
              var o = {x: source.x, y: source.y}
              return diagonal(o, o)
            })
            .remove();

        // Store the old positions for transition.
        nodes.forEach(function(d){
          d.x0 = d.x;
          d.y0 = d.y;
        });

        // Creates a curved (diagonal) path from parent to the child nodes
        function diagonal(s, d) {

          var path = "M " + s.y + " " + s.x +
                " C " + (s.y + d.y)/2 + " " + s.x + "," +
                  (s.y + d.y)/2 + " " + d.x + "," +
                  d.y + " " + d.x;


          return path
        }

        // Toggle children on click.
        function click(d) {
          if (d.children) {
              d._children = d.children;
              d.children = null;
            } else {
              d.children = d._children;
              d._children = null;
            }
          update(d);
        }

        var zoom = d3.zoom()
          .scaleExtent([1 / 2, 8])
          .on("zoom", zoomed)
        _chart.zoom = zoom;
        svg.call(zoom);

        function zoomed() {
          g.attr("transform", d3.event.transform);
        }

      }

      function stratifyJSONArray(data){
          // transform JSONArray structure into D3 hierarchy, and perform some computation of attributes along the way.  This function will be called by the chart to process the data.

          // create the tree structure
          var rootNode = {path:_config.commonRootPathName, id:_config.commonRootPathName, "name":_config.commonRootPathName, type:"start", is_new_skill:0, is_session_start:0, dropped_off:0, rerouted:0, flows:0, not_handled:0, dropped_offRatio: 0, reroutedRatio: 0, flowRatio: 100, notHandledRatio: 0 };

          // update path of all elements to have shared session start element
          data.forEach(function(row) {row.path = _config.commonRootPathName + "\\" + row.path});
          // add a parent node
          data.push(rootNode);
          // let d3 stratify the data into a tree
          var toHierarchy = d3.stratify()
                .parentId(function (d) {
                    return d.path.substring(0, d.path.lastIndexOf("\\"));
                })
                .id(function (d) {
                    return d.path;
                });
          var root = toHierarchy(data);
          //var root = toHierarchy(data);
          // compute aggregates for root node based on children
          for (var childIndex in root.children) {
          //root.children.foreach(function(node){
          //    root.data.exits += root.children[childIndex].data.exits;
              root.data.flows += root.children[childIndex].data.flows;
          };
          // compute percentages
          root.each(function(node) {
              //formatPercentage = (12.555 * 100).toFixed(1) + " %";
              node.data.dropped_offRatio = node.data.dropped_off / node.data.flows;
              node.data.reroutedRatio = node.data.rerouted / node.data.flows;
              node.data.flowRatio = node.data.flows / root.data.flows;
              node.data.notHandledRatio = node.data.not_handled / node.data.flows;

          });
          // sort by flowRatio
          // root.sort(function(a, b) {
          //   return a.data.flowRatio < b.data.flowRatio;
          // })
          return root;

      }

      function createToolBar(_chart) {
        var toolbar = $('<div>').addClass("botvis flowchart toolbar").appendTo(_chart.container);
        var button1 = $('<button>', { text: 'export list of IDs'}).addClass("botvis flowchart button").appendTo(toolbar);
        var button2 = $('<button>', { text: 'export unique path'}).addClass("botvis flowchart button").appendTo(toolbar);
        var button3 = $('<button>', { text: 'reset to center'}).addClass("botvis flowchart button").appendTo(toolbar);
        var label = $('<label>', { text: 'Selection: <none>'}).addClass("botvis flowchart selection").appendTo(toolbar);
        var label = $('<label>', { text: '(click on an exit node to select dropped off or rerouted conversations)'}).addClass("botvis flowchart selection-instruction").appendTo(toolbar);
        button1.click(function(e) {
          //alert("List of abandoned conversation IDs copied to Python 'selection' variable");
          var handler = _chart.eventHandler["export"];
          if (handler){
            //debugger;
            var selection = {"dropped_off": [], "rerouted": []};
            //if (_chart.selectedNode.hasOwnProperty("conversation_log_ids"))
            //  selection = _chart.selectedNode.conversation_log_ids;
            if (_chart.selectedNode.hasOwnProperty("conversation_log_ids_dropped_off"))
              selection.dropped_off = _chart.selectedNode.conversation_log_ids_dropped_off;
              if (_chart.selectedNode.hasOwnProperty("conversation_log_ids_rerouted"))
                selection.rerouted = _chart.selectedNode.conversation_log_ids_rerouted;
            e.selection = selection;
            $(".botvis.flowchart.selection-instruction")[0].innerText ="Copied " + selection.dropped_off.length + " (dropped off) and " +
            + selection.rerouted.length + " (rerouted) conversations to Python 'selection' variable";
            handler(e);
          }
        });
        button2.click(function(e) {
          //alert("Unique path of abandoned conversations copied to Python 'selection' variable");
          var handler = _chart.eventHandler["export"];
          if (handler){
            //debugger;
            _chart.selectedNode;
            //var selectedPath = $(".botvis.flowchart.label")[0].innerText;
            var selection = _chart.selectedNode.path;
            e.selection = selection;
            $(".botvis.flowchart.selection-instruction")[0].innerText ="Copied unique path to Python 'selection' variable";
            handler(e);
          }
        });
        button3.click(function(e) {
          alert("to be implemented");
          resetToCenter(_chart)}
        );

        _chart.eventHandler = [];

        _chart.on = function(event,fct){
          _chart.eventHandler[event] = fct;
        };
      }

      function resetToCenter(_chart) {
          d3;
          var scale = 1.0;
          _chart.svg.attr("transform", "translate(0,0)scale(1,1)");
          _chart.zoom.scale(scale)
              .translate([0,0]);
      };

      return _chart;
  }



 return draw;
});
