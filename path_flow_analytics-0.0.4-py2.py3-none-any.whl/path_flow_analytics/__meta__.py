# Automatically created. Please do not edit.
__version__ = u'0.0.4'
__author__ = u'Lior Turgeman'
