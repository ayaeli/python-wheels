'''
Created on May 26, 2019

@author: sergeyz
'''
import re
import pandas as pd

#######################################################################
# sklearn
from sklearn.model_selection import train_test_split
from sklearn.utils import resample
from sklearn.feature_extraction.text import TfidfVectorizer 
from sklearn.metrics import accuracy_score
from sklearn.pipeline import Pipeline 
from sklearn.linear_model import SGDClassifier

################################################
import nltk
from nltk.corpus import stopwords

####################################################################

from plot_functions import show_word_cloud2, plot_frequencies 

#####################################################################
# Default option to produce weight for word clouds
def produce_weights(n):
    weights=[]
    w=1.0/n+1.0/(2.0*n)
    for i in range(0,n):       
        weights.append(w)
        w-=(1.0/n)/(n-1)
    return(weights)

##############################################################
# returns clean string
def clean_text(text):     
    
    REPLACE_BY_SPACE_RE = re.compile('[/(){}\[\]\|@,;]')
    BAD_SYMBOLS_RE = re.compile('[^0-9a-z #+_]')
    REGULAR_STOPWORDS = set(stopwords.words('english'))
    
    # not a perfect mechanism
    CUSTOM_STOPWORDS={"like","would","tell","still","gone","want","get","said","wont","new","take","taken","see","says","say","saying","look","looking","one",\
                      "made","make","back","put","go","going","went","yes","no","00","set","come","came"}
        
    STOPWORDS = REGULAR_STOPWORDS | CUSTOM_STOPWORDS
     
    text = text.lower() # lowercase text
    text = REPLACE_BY_SPACE_RE.sub(' ', text) # replace REPLACE_BY_SPACE_RE symbols by space in text
    text = BAD_SYMBOLS_RE.sub('', text) # delete symbols which are in BAD_SYMBOLS_RE from text
    text = ' '.join(word for word in text.split() if word not in STOPWORDS) # delete stopwors from text
    return text

##############################################################
# Get frequencies of most significant features
def get_frequency(text_corpus,text):
    num_text = len(text_corpus)
    if len(text.split())==1: # single word
            return ((100*len([k for k in text_corpus if text in k.split()]))/num_text)             
    else:
        return ((100*len([k for k in text_corpus if text in k]))/num_text) 
    
##########################################################################################################
def get_df_frequencies(text_negative, text_positive, neg_list, pos_list):
    neg_list_neg_freq=[]
    neg_list_pos_freq=[]
    pos_list_neg_freq=[]
    pos_list_pos_freq=[]
    
    num_negative=len(text_negative)
    num_positive=len(text_positive)
    num_features=len(neg_list)
    
    for i in range(0, num_features):
        if len(neg_list[i].split())==1: # single word
            neg_list_neg_freq.append((100*len([k for k in text_negative if neg_list[i] in k.split()]))/num_negative)
            neg_list_pos_freq.append((100*len([k for k in text_positive if neg_list[i] in k.split()]))/num_positive)
        else:
            neg_list_neg_freq.append((100*len([k for k in text_negative if neg_list[i] in k]))/num_negative)
            neg_list_pos_freq.append((100*len([k for k in text_positive if neg_list[i] in k]))/num_positive)
        if len(pos_list[i].split())==1: # single word
            pos_list_neg_freq.append((100*len([k for k in text_negative if pos_list[i] in k.split()]))/num_negative)
            pos_list_pos_freq.append((100*len([k for k in text_positive if pos_list[i] in k.split()]))/num_positive)
        else:
            pos_list_neg_freq.append((100*len([k for k in text_negative if pos_list[i] in k]))/num_negative)
            pos_list_pos_freq.append((100*len([k for k in text_positive if pos_list[i] in k]))/num_positive)

    df_frequencies = pd.DataFrame() 
    df_frequencies["Failure keywords"] = neg_list 
    df_frequencies["Failure keywords: negative corpus frequencies, %"] = neg_list_neg_freq
    df_frequencies["Failure keywords: positive corpus frequencies, %"] = neg_list_pos_freq
    df_frequencies["Success keywords"] = pos_list
    df_frequencies["Success keywords: positive corpus frequencies, %"] = pos_list_pos_freq
    df_frequencies["Success keywords: negative corpus frequencies, %"] = pos_list_neg_freq
    df_frequencies.head(n=100)
    return df_frequencies    

##########################################################################################
# Create training and testing sets
def create_test_train(text_positive, text_negative, clean, balance):
    
    PRINT_MODE=False
    
    if clean:
        text_positive = [clean_text(x) for x in text_positive]
        text_negative = [clean_text(x) for x in text_negative]
    
    num_positive=len(text_positive)
    num_negative=len(text_negative) 
    
    if balance=="truncate":
              
        if num_positive>num_negative:
            if PRINT_MODE:
                print("Truncate positive sample to get balanced data")
            sample = text_positive[0:num_negative] + text_negative
            outcome=["positive"] * num_negative + ["negative"] * num_negative

        elif num_positive<=num_negative:
            if PRINT_MODE:
                print("Truncate negative sample to get balanced data")
            sample = text_positive + text_negative[0:num_positive]
            outcome=["positive"] * num_positive+["negative"] * num_positive   
    
    elif balance=="resample":           
        
        if num_positive>num_negative:
            if PRINT_MODE:
                print("Resample negative sample to get balanced data")
            text_negative2 = resample(text_negative, replace=True, n_samples=num_positive-num_negative)
            #text_negative2 = random.sample(text_negative, num_positive-num_negative)
            sample = text_positive + text_negative + text_negative2
            outcome=["positive"] * num_positive+["negative"] * num_positive 
        # TODO : treat zero
        elif num_positive<=num_negative:
            if PRINT_MODE:
                print("Bootstrap positive sample to get balanced data")
            text_positive2 = resample(text_positive, replace=True, n_samples=num_negative-num_positive)
            sample = text_positive + text_positive2 + text_negative
            outcome=["positive"] * num_negative + ["negative"] * num_negative 
        
    
    text_train, text_test, outcome_train, outcome_test = train_test_split(sample, outcome, test_size=0.25, random_state = 20)
    
    if PRINT_MODE:
        print("Size of training set: "+str(len(text_train)))
        print("Size of testing set: "+str(len(text_test)))
    
    return text_train, text_test, outcome_train, outcome_test

########################################################################
def get_features(text_negative, text_positive, text_train, text_test, outcome_train, outcome_test, num_features, coeff_method):
     
   
    # loss = hinge corresponds to linear SVM
    # penalty - regularization
    # alpha - related to regularization and learning rate 
     
    PRINT_MODE=False
    
    sgd = Pipeline([('vect_tfifd', TfidfVectorizer(ngram_range=(1, 2))), 
                    ('clf', SGDClassifier(loss='hinge', penalty='l2',alpha=1e-3, random_state=20,\
                                          max_iter=20, tol=None, fit_intercept=False)),])

    # fit model
    sgd_est = sgd.fit(text_train, outcome_train)

    outcome_pred = sgd.predict(text_test)
    
    if PRINT_MODE:
        print('accuracy %s' % accuracy_score(outcome_pred, outcome_test))
    
    feature_names = sgd_est.named_steps['vect_tfifd'].get_feature_names()
    feature_coeffs = sgd_est.named_steps['clf'].coef_[0]
 
    coeffs_with_features = sorted(zip(feature_coeffs, feature_names))
    
    ##############################
    # perform frequence check, print warnings
    counter_neg_features=0
    counter=0
    top_neg=[]
    while counter_neg_features<num_features:
        current_neg_feature=coeffs_with_features[counter][1] 
        get_neg_freq=get_frequency(text_negative,current_neg_feature)
        get_pos_freq=get_frequency(text_positive,current_neg_feature)
        
        if get_pos_freq>=get_neg_freq:
            if PRINT_MODE:
                print("Frequencies for negative feature "+current_neg_feature+" are not consistent. Feature is omitted")
                print("Negative frequency: "+str(get_neg_freq))
                print("Positive frequency: "+str(get_pos_freq))
        else:
            top_neg.append(coeffs_with_features[counter])
            counter_neg_features+=1
        
        counter+=1 
        
    counter_pos_features=0
    counter=0
    top_pos=[]
    while counter_pos_features<num_features:
        current_pos_feature=coeffs_with_features[-(counter+1)][1] 
        get_neg_freq=get_frequency(text_negative,current_pos_feature)
        get_pos_freq=get_frequency(text_positive,current_pos_feature)         
        
        if get_pos_freq<=get_neg_freq:
            if PRINT_MODE:
                print("Frequencies for positive feature '"+current_pos_feature+"' are not consistent. Feature is omitted.")
                print("Negative frequency: "+str(get_neg_freq))
                print("Positive frequency: "+str(get_pos_freq))
        else:
            top_pos.append(coeffs_with_features[-(counter+1)])
            counter_pos_features+=1
        
        counter+=1    
        
    #top_neg = coeffs_with_features[0:num_features] 
    #top_pos = coeffs_with_features[:-(num_features + 1):-1]   
    neg_dict={} 
    pos_dict={}
    neg_list=[]
    pos_list=[]
    
    w=produce_weights(num_features)
    for i in range(0,num_features): 
        neg_list.append(top_neg[i][1])
        pos_list.append(top_pos[i][1])
        if coeff_method=="model":
            neg_dict[top_neg[i][1]] = -top_neg[i][0]
            pos_dict[top_pos[i][1]] = top_pos[i][0]
        elif coeff_method=="default":
            neg_dict[top_neg[i][1]] = w[i]
            pos_dict[top_pos[i][1]] = w[i]
    
    return neg_dict, pos_dict, neg_list, pos_list 

########################################################################
def keyword_clouds(text_negative, text_positive, num_features):
    do_cleaning = True
    balance_method="resample" # truncate is another
    
    text_train, text_test, outcome_train, outcome_test = create_test_train(text_positive, text_negative, do_cleaning, balance_method) 
     
    cloud_dict1, cloud_dict2, neg_list, pos_list =  get_features(text_negative, text_positive, text_train, text_test, outcome_train, outcome_test,num_features,"default") 
    
    cloud_title1="Failure Keywords"
    cloud_title2="Success Keywords"
    show_word_cloud2(cloud_dict1,cloud_title1,cloud_dict2,cloud_title2)
    
    return

########################################################################
def keyword_bar_frequencies(text_negative, text_positive, num_bars):
     
    #############################################################################
    do_cleaning = True
    balance_method="resample" # truncate is another
    
    text_train, text_test, outcome_train, outcome_test = create_test_train(text_positive, text_negative, do_cleaning, balance_method) 
    
    cloud_dict1, cloud_dict2, neg_list, pos_list =  get_features(text_negative, text_positive, text_train, text_test,\
                                                        outcome_train, outcome_test, num_bars, "default") 
   
    df_frequencies = get_df_frequencies(text_negative, text_positive, neg_list, pos_list) 
    
    plot_frequencies(df_frequencies)
    
    return

########################################################################
def keyword_table_frequencies(text_negative, text_positive, num_keywords):
     
    #############################################################################
    do_cleaning = True
    balance_method="resample" # truncate is another
    
    text_train, text_test, outcome_train, outcome_test = create_test_train(text_positive, text_negative, do_cleaning, balance_method) 
    
    cloud_dict1, cloud_dict2, neg_list, pos_list =  get_features(text_negative, text_positive, text_train, text_test,\
                                                        outcome_train, outcome_test, num_keywords, "default") 
   
    df_frequencies = get_df_frequencies(text_negative, text_positive, neg_list, pos_list) 
     
    return df_frequencies