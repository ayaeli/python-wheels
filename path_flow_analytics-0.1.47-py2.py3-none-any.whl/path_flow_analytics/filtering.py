import pandas as pd
import numpy as np

#######################################################################
#filter logs by included node
def by_included_node(node, df_logs_formated):
    """
    return subset of conversations that contains specific node
    """
    # create an empty dataframe with the same column names and types
    filtered_df_logs = pd.DataFrame(data=None, columns=df_logs_formated.columns)
    for column in filtered_df_logs.columns:
        filtered_df_logs[column] = filtered_df_logs[column].astype(df_logs_formated[column].dtypes.name)

    # TODO: should we sort?
    df_by_conversation_id = df_logs_formated.sort_values(by=["response_timestamp"]).groupby(by="conversation_id")
    # TODO: potentially iterate over groupby
    ConvDict = {}
    for key, group in df_by_conversation_id:
        ConvDict[key] = group

    for i, (k, v) in enumerate(ConvDict.items()):
        # consider if we need to sort
        dfP1=pd.DataFrame(v, columns=v.columns).sort_values(by=['response_timestamp'])
        if any(dfP1['node_visited'] == node):
            filtered_df_logs = pd.concat([filtered_df_logs,dfP1])

    if filtered_df_logs.empty:
        print('Filtering yielded an empty dataframe. Path flow analysis requires a non-empty dataframe.')

    print('Initial amount of records (before filtering):', len(df_logs_formated))
    print('Amount of filtered records:', len(df_logs_formated)-len(filtered_df_logs))
    print('Final amount of records (after filtering):', len(filtered_df_logs))

    return filtered_df_logs


#######################################################################
#filter logs by included node
def by_included_absolute_path(path, df_logs_formated):
    """
    return subset of conversations that contains specific node
    @param path path: array
    """
    # create an empty dataframe with the same column names and types
    filtered_df_logs = pd.DataFrame(data=None, columns=df_logs_formated.columns)
    for column in filtered_df_logs.columns:
        filtered_df_logs[column] = filtered_df_logs[column].astype(df_logs_formated[column].dtypes.name)

    # TODO: should we sort?
    df_by_conversation_id = df_logs_formated.sort_values(by=["response_timestamp"]).groupby(by="conversation_id")
    # TODO: potentially iterate over groupby
    ConvDict = {}
    for key, group in df_by_conversation_id:
        ConvDict[key] = group

    for i, (k, v) in enumerate(ConvDict.items()):
        # consider if we need to sort
        dfP1=pd.DataFrame(v, columns=v.columns).sort_values(by=['response_timestamp'])
        # length of conversation is at least length of path
        if len(dfP1) >= len(path):
            for i in range(len(path)):
                if path[i] != dfP1.iloc[i]['node_visited']:
                    break
                # last element
                if i == len(path)-1:
                     filtered_df_logs = pd.concat([filtered_df_logs,dfP1])

    if filtered_df_logs.empty:
        print('Filtering yielded an empty dataframe. Path flow analysis requires a non-empty dataframe.')

    print('Initial amount of records (before filtering):', len(df_logs_formated))
    print('Amount of filtered records:', len(df_logs_formated)-len(filtered_df_logs))
    print('Final amount of records (after filtering):', len(filtered_df_logs))

    return filtered_df_logs

## filter conversations starting with initial intent
# TODO: think about enhanced version: filter nodes that condition on the intent
def by_initial_intent(intent, df_logs_formated):
    """
    filter conversations starting with initial intent
    """
    # create an empty dataframe with the same column names and types
    filtered_df_logs = pd.DataFrame(data=None, columns=df_logs_formated.columns)
    for column in filtered_df_logs.columns:
        filtered_df_logs[column] = filtered_df_logs[column].astype(df_logs_formated[column].dtypes.name)
    df_by_conversation_id = df_logs_formated.sort_values(by=["response_timestamp"]).groupby(by="conversation_id")

    ConvDict = {}
    for key, group in df_by_conversation_id:
        ConvDict[key] = group

    for i, (k, v) in enumerate(ConvDict.items()):
        dfP1=pd.DataFrame(v, columns=v.columns).sort_values(by=['response_timestamp'])
        if (dfP1['intent'].iloc[0] == intent):
            filtered_df_logs = pd.concat([filtered_df_logs,dfP1])
    if filtered_df_logs.empty:
        print('Filtering yielded an empty dataframe. Path flow analysis requires a non-empty dataframe.')

    print('Initial amount of records (before filtering):', len(df_logs_formated))
    print('Amount of filtered records:', len(df_logs_formated)-len(filtered_df_logs))
    print('Final amount of records (after filtering):', len(filtered_df_logs))

    return filtered_df_logs

## filtering by truncating conversations from selected node onwards

def from_node_onwards(node, df_logs_formated):
    """
    filtering by truncating conversations from selected node onwards
    """
    # create an empty dataframe with the same column names and types
    filtered_df_logs = pd.DataFrame(data=None, columns=df_logs_formated.columns)
    for column in filtered_df_logs.columns:
        filtered_df_logs[column] = filtered_df_logs[column].astype(df_logs_formated[column].dtypes.name)

    df_by_conversation_id = df_logs_formated.sort_values(by=["response_timestamp"]).groupby(by="conversation_id")
    for conversation_id, conversation_df in df_by_conversation_id:
        i=0
        for index, row in conversation_df.iterrows():
            i=i+1
            node_visited = row["node_visited"]

            if node == node_visited:
                num_of_elements_to_copy = len(conversation_df)-i+1
                filtered_df_logs = pd.concat([filtered_df_logs,conversation_df.tail(num_of_elements_to_copy)])
                break
    if filtered_df_logs.empty:
        print('Filtering yielded an empty dataframe. Path flow analysis requires a non-empty dataframe.')

    print('Initial amount of records (before filtering):', len(df_logs_formated))
    print('Amount of filtered records:', len(df_logs_formated)-len(filtered_df_logs))
    print('Final amount of records (after filtering):', len(filtered_df_logs))

    return filtered_df_logs

## filter by dates
# TODO: consider to remove date as a mandatory field in canonical model
def by_date_range (df, start_date, end_date):
    df['Date'] = pd.to_datetime(df['Date'])
    mask = (df['Date'] > start_date) & (df['Date'] <= end_date)
    df_1 = df.loc[mask].reset_index()

    if df_1.empty:
        print('Filtering yielded an empty dataframe. Path flow analysis requires a non-empty dataframe.')

    print('Initial amount of records (before filtering):', len(df))
    print('Amount of filtered records:', len(df)-len(df_1))
    print('Final amount of records (after filtering):', len(df_1))

    return df_1
