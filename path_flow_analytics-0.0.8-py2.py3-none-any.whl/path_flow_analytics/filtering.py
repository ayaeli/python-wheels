import pandas as pd
import numpy as np

#filter logs by included node
def by_included_node(node, df_logs):
    filtered_df_logs = None

    UniqueConv = df_logs.conversation_id.unique()
    ConvDict = {elem : pd.DataFrame for elem in UniqueConv}
    for key in ConvDict.keys():
        ConvDict[key] = df_logs[:][df_logs.conversation_id == key]

    for i, (k, v) in enumerate(ConvDict.items()):
        dfP1=pd.DataFrame(v, columns=v.columns).sort_values(by=['response_timestamp'])
        if any(dfP1['node_visited'] == node):
            filtered_df_logs = pd.concat([filtered_df_logs,dfP1])
    return filtered_df_logs

## filter conversations starting with initial intent
def by_initial_intent(intent, df_logs):
    filtered_df_logs = None

    UniqueConv = df_logs.conversation_id.unique()
    ConvDict = {elem : pd.DataFrame for elem in UniqueConv}
    for key in ConvDict.keys():
        ConvDict[key] = df_logs[:][df_logs.conversation_id == key]

    for i, (k, v) in enumerate(ConvDict.items()):
        dfP1=pd.DataFrame(v, columns=v.columns).sort_values(by=['response_timestamp'])
        if (dfP1['response_intent'].iloc[0] == intent):
            filtered_df_logs = pd.concat([filtered_df_logs,dfP1])
    return filtered_df_logs

## filtering by truncating conversations from selected node onwards
def by_node_onwards(node, df_logs):
    filtered_df_logs = None

    UniqueConv = df_logs.conversation_id.unique()
    ConvDict = {elem : pd.DataFrame for elem in UniqueConv}
    for key in ConvDict.keys():
        ConvDict[key] = df_logs[:][df_logs.conversation_id == key]

    for i, (k, v) in enumerate(ConvDict.items()):
        dfP1 = pd.DataFrame(v, columns=v.columns).sort_values(by=['response_timestamp'])
        if any(dfP1['node_visited'] == node):
            dfP1 = dfP1.reset_index()
            dfP1 = dfP1.iloc[dfP1.index[dfP1['node_visited'] == node].tolist()[0]:len(dfP1),:]
            filtered_df_logs = pd.concat([filtered_df_logs,dfP1])
    return filtered_df_logs


## filter by dates
def by_date (df_logs, start_date, end_date):
    """Filter by
    """
    filtered_df_logs = None

    mask = (pd.to_datetime(df_logs['Date']) > start_date) & (pd.to_datetime(df_logs['Date']) <= end_date)
    filtered_df_logs = df_logs.loc[mask].reset_index()
    return filtered_df_logs
