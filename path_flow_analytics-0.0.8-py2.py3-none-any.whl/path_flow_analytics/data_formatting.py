import pandas as pd
import decimal
import pandas as pd
import datetime
import re

def format_data(df, nodes_dict):
    df1 = pd.concat([df.drop(['request', 'response'], axis=1).reset_index(drop=True),
                     df['request'].apply(pd.Series).add_prefix('request_').reset_index(drop=True),
                     pd.DataFrame(df['response']
                                  .tolist()).add_prefix('response_')], axis=1)  # type: pd.DataFrame
    df1['request_input'] = pd.io.json.json_normalize(df['request'])['input.text']

    # Add context and output fields
    df2 = pd.concat([df1.drop(['response_context', 'response_output'], axis=1),
                     df1['response_context'].apply(pd.Series).add_prefix('response_context_'),
                     pd.DataFrame(df1['response_output'].tolist()).add_prefix('response_')],axis=1)  # type: pd.DataFrame
    # Add context_system fields
    df3 = pd.concat([df2.drop(['response_context_system'], axis=1),
                     df2['response_context_system'].apply(pd.Series).add_prefix('response_')],
                    axis=1)  # type: pd.DataFrame
    cols = ['log_id', 'response_timestamp', 'request_input', 'response_text' ,'response_context_conversation_id','response_nodes_visited', 'response_branch_exited', 'response_branch_exited_reason']
    df4 = df3[cols].copy(deep=True)  # type: pd.DataFrame

    df4.rename(columns={'response_nodes_visited': 'nodes_visited',
                        'response_context_conversation_id': 'conversation_id',
                       }, inplace=True)
    df4['node_visited']=df4['nodes_visited'].apply(lambda x:x[-1])
    df4['response_timestamp'] = pd.to_datetime(df4['response_timestamp'])
    df4['Date'] = [datetime.datetime.date(d) for d in df4['response_timestamp']]  
    df4['node_visited'] = df4['node_visited'].replace(nodes_dict)
    return df4

def _format_data(df, nodes_dict):
    df['node_visited']=df['nodes_visited'].str.strip('[]')
    pattern = re.compile(",")
    df['node_visited']=df['node_visited'].apply(lambda x:pattern.split(x))
    df['node_visited']=df['node_visited'].apply(lambda x:x[-2].replace("'", "").lstrip() if (len (x)>2 and (str(x[-2]).replace("'", "").lstrip()=='Handoff' or str(x[-2]).replace("'", "").lstrip()=='More Help')) else x[-1].replace("'", "").lstrip())

    df.loc[:, 'Date'] = df.response_timestamp.apply(lambda x: pd.datetime.fromtimestamp(x/1000).date())
    df['node_visited'] = df['node_visited'].replace(nodes_dict)
    return df



def conv_id_dict (df_logs_formated):
    UniqueConv = df_logs_formated.conversation_id.unique()
    ConvDict = {elem : pd.DataFrame for elem in UniqueConv}
    for key in ConvDict.keys():
        ConvDict[key] = df_logs_formated[:][df_logs_formated.conversation_id == key]
    return ConvDict





