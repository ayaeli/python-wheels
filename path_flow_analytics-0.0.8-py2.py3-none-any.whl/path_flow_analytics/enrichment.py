### obsolete mnodule


import pandas as pd
import numpy as np

def extract_dialog_node_name_WA(workspace_nodes):
    """
    Extract more friendly dialog node names from the Watson Assistant workspace
    return a nodes dictionary object.
    """

    nodes_dict = {}
    nodes_type = {}
    for idx,obj in workspace_nodes.iterrows():
        if (obj['type']=='standard') and not (obj['title'] is np.nan or obj['title'] != obj['title']):
            nodes_dict[obj['dialog_node']]=obj['title']
        else:
            nodes_dict[obj['dialog_node']]=obj['dialog_node']
    return nodes_dict


def _extract_dialog_node_name(dialog_nodes):
    nodes_dict = {}
    nodes_type = {}
    for obj in dialog_nodes:
        if (obj['type']=='standard') and (obj['title'] is not None):
            nodes_dict[obj['dialog_node']]=obj['title']
        else:
            nodes_dict[obj['dialog_node']]=obj['dialog_node']
    return nodes_dict
