
import datetime
import json

def _wa_to_ba_json(row):
    row_request = row["request"]
    row_response = row["response"]

    ba_json = {}
    ba_json["event"] = "REQUEST_RESPONSE"

    timestring = row.request_timestamp[:19]
    ba_json["timestamp"] = str(int(datetime.datetime.strptime(timestring, "%Y-%m-%dT%H:%M:%S").timestamp())) + '000'

    ba_json["log_id"]=row["log_id"]

    ba_json["data"] = {}
    ba_json["data"]["input"] = { "text": row_request["input"]["text"] }
    ba_json["data"]["intents"] = row_response["intents"]
    ba_json["data"]["entities"] = row_response["entities"]
    ba_json["data"]["output"] = {
        "text" : row_response["output"]["text"],
        "nodes_visited": row_response["output"]["nodes_visited"]
    }

    if 'branch_exited' in row_response["context"]["system"]:
        ba_json["data"]["output"]["branch_exited"] = row_response["context"]["system"]["branch_exited"]
        ba_json["data"]["output"]["branch_exited_reason"] = row_response["context"]["system"]["branch_exited_reason"]

    ba_json["data"]["context"] = {}
    ba_json["data"]["context"]["conversation_id"] = row_response["context"]["conversation_id"]
    if "user_id" in row_response["context"]:
        ba_json["data"]["context"]["user_id"] = row_response["context"]["user_id"]
    if "workspace_name" in row_response["context"]:
        ba_json["data"]["context"]["workspace_name"] = row_response["context"]["workspace_name"]
    if "not_handled" in row_response["context"]:
        # optional. Boolean. Default value is false.
        ba_json["data"]["context"]["not_handled"] = row_response["context"]["not_handled"]

    ba_json["data"]["context"]["input_type"] = "text"
    return ba_json

# create row for sql table
def _wa_to_ba_transformer(row, tenant_id):
    ba_row=[]

    ba_row.append(row["log_id"])
    event_json = _wa_to_ba_json(row)
    ba_row.append(json.dumps(event_json))
    ba_row.append(int(event_json["timestamp"]))
    ba_row.append(tenant_id)

    return ba_row

def transform_wa_to_ba(df_logs, tenant_id):
    """
    Transforms WA log dataframe format to BA array format
    """
    # iterate to get list of rows for sql table
    ba_array = []
    for index, row in df_logs.iterrows():
        ba_array.append(_wa_to_ba_transformer(row, tenant_id))
    return ba_array

# store ba_array to the database
def store_ba_to_mysql(ba_array, db_credentials, tenant_id, raw_data_table='analyticsRecords'):
    """
    Persist ba array to MySQL
    """
    import pymysql
    # establish a connection
    db_connection = pymysql.connect(
        host=db_credentials["host"],
        port=db_credentials["port"],
        user=db_credentials["user"],
        password=db_credentials["password"],
        db=db_credentials["database"],
        charset="utf8")

    # insert data to sql table
    try:
        with db_connection.cursor() as db_cursor:
            field_list="(id, event_json, epoch, tenant_id)"
            insert_stmt = "INSERT INTO "+raw_data_table+" "+field_list+" VALUES (%s,%s,%s,%s)"
            db_cursor.executemany(insert_stmt,ba_array)
    except Exception as e:
            print(e)
            print("Failure in database connection")

    db_connection.commit()
    db_connection.close()
