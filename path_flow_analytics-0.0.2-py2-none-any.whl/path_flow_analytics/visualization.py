import sys
import requests
from IPython.display import display, Javascript, HTML
import json

display(Javascript("require.config({paths: {d3: 'https://cdnjs.cloudflare.com/ajax/libs/d3/4.13.0/d3.min'}});"))
#display(Javascript("require.config({paths: {d3: 'https://d3js.org/d3.v5.min'}});"))
display(Javascript(filename="flowchart2.js"))
display(HTML(filename="flowchart.css.html"))

def draw_flowchart_2(config, json_data, width=600, height=400):
    display(Javascript("""
        (function(element){
            require(['flowchart2'], function(flowchart2) {
                debugger;
                var chart = flowchart2(element.get(0), %s, %s);
                
                chart.on("export",function(e){
                    debugger;
                    var selection = JSON.stringify(e.selection).replace(/"/g , "'");   
                    IPython.notebook.kernel.execute("selection = " + selection);
                });
                debugger;
            });
        })(element);
    """ % (json.dumps(config), json.dumps(json_data))))