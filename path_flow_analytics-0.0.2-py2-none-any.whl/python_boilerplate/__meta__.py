# Automatically created. Please do not edit.
__version__ = u'0.4.10'
__author__ = u'F\xe1bio Mac\xeado Mendes'
