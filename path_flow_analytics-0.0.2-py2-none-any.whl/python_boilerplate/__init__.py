from .__meta__ import __author__, __version__
