import pandas as pd
import numpy as np

def to_dataframe(selection):
    """convert selection tuples to dataframe
    """
    result = {}

    if len(selection["rerouted"]) == 0:
        result['rerouted'] = pd.DataFrame(columns=['conversation_id','log_id'], dtype='object')
    else:
        result['rerouted'] = pd.DataFrame({'conversation_id': np.array(list(zip(*selection["rerouted"]))[0]), 'log_id': np.array(list(zip(*selection["rerouted"]))[1])})

    if len(selection["dropped_off"]) == 0:
        result['dropped_off'] = pd.DataFrame(columns=['conversation_id','log_id'], dtype='object')
    else:
        result['dropped_off'] = pd.DataFrame({'conversation_id': np.array(list(zip(*selection["dropped_off"]))[0]), 'log_id': np.array(list(zip(*selection["dropped_off"]))[1])})
    #return pd.DataFrame({'conversation_id': np.array(list(zip(*selection))[0]), 'log_id': np.array(list(zip(*selection))[1])})
    return result

def extract_conversation_transcript(df_logs, selection_df, index):
    """extract conversation transcript from logs, based on selection df, and index of interest
    """
    selected_by_index = selection_df.iloc[index]
    transcript = df_logs[df_logs['conversation_id'] == selected_by_index['conversation_id']]
    transcript['you_are_here'] = ""
    transcript.loc[transcript['log_id'] == selected_by_index['log_id'], 'you_are_here'] = '--->'
    return transcript[['you_are_here','response_timestamp','request_input','response_text','log_id','conversation_id','nodes_visited', 'node_visited',
       'response_branch_exited', 'response_branch_exited_reason']]

def fetch_logs(logs_df, selection_df):
    return logs_df[logs_df['log_id'].isin(list(selection_df['log_id']))]
