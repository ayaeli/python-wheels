import pandas as pd
import numpy as np
import decimal
import datetime
import re

def to_canonical_WA(df, nodes_dict):
    """
    transform WA log format into pathflow dataframe canonical data model
    returns a canonical dataframe with the following mandatory columns

    'log_id'
    'conversation_id'
    'node_visited'
    'response_timestamp'
    'branch_exited'
    'branch_exited_reason'
    'intent'

    the following fields are optional:

    'response_type'
    'request_text'
    'response_text'
    """

    df1 = pd.concat([df.drop(['request', 'response'], axis=1).reset_index(drop=True),
                     df['request'].apply(pd.Series).add_prefix('request_').reset_index(drop=True),
                     pd.DataFrame(df['response']
                                  .tolist()).add_prefix('response_')], axis=1)
    df1['request_input'] = pd.io.json.json_normalize(df['request'])['input.text']
    df2 = pd.concat([df1.drop(['response_context', 'response_output'], axis=1), df1['response_context'].apply(pd.Series).add_prefix('response_context_'), pd.DataFrame(df1['response_output'].tolist()).add_prefix('response_output_')], axis=1)
    df3 = pd.concat([df2.drop(['response_context_system'], axis=1), df2['response_context_system'].apply(pd.Series).add_prefix('response_context_system_')], axis=1)

    if 'response_output_generic' in df3:
        df4 = pd.concat([df3.drop(['response_output_generic'], axis=1), df3['response_output_generic'].apply(pd.Series).add_prefix('response_output_generic_')], axis=1)
    else:
        df4 = df3


    #cols = ['log_id', 'response_timestamp', 'request_input', 'response_output_text' ,'response_context_conversation_id','response_output_nodes_visited', 'response_context_system_branch_exited', 'response_context_system_branch_exited_reason','response_intents',#'response_output_generic_response_type']
    ## HOTFIX - due to broken line
    cols = ['log_id', 'response_timestamp', 'request_input', 'response_output_text' ,'response_context_conversation_id','response_output_nodes_visited', 'response_context_system_branch_exited', 'response_context_system_branch_exited_reason','response_intents']
    #'response_output_generic_response_type']

    df5 = df4[cols].copy(deep=True)
    df5.rename(columns={'response_output_nodes_visited': 'nodes_visited',
                        'response_context_conversation_id': 'conversation_id',
                        'request_input' : 'request_text',
                        'response_output_text': 'response_text',
                        'response_context_system_branch_exited' : 'branch_exited',
                        'response_context_system_branch_exited_reason' : 'branch_exited_reason',
                        'response_intents' : 'intent'
                        #response_output_generic_response_type' : 'type'
                       }, inplace=True)
    df5['node_visited']=df5['nodes_visited'].apply(lambda x:x[-1])
    df5['response_timestamp'] = pd.to_datetime(df5['response_timestamp'])
    df5['Date'] = [datetime.datetime.date(d) for d in df5['response_timestamp']]
    df5['node_visited'] = df5['node_visited'].replace(nodes_dict)
    return df5

def _to_canonical(df, nodes_dict):
    df.rename(columns={'document_id': 'log_id'}, inplace=True)
    df.rename(columns={'branch_exited': 'response_branch_exited'}, inplace=True)
    df.rename(columns={'branch_exited_reason': 'response_branch_exited_reason'}, inplace=True)
    df.loc[:, 'Date'] = df.response_timestamp.apply(lambda x: pd.datetime.fromtimestamp(x/1000).date())
    sym_list = str.maketrans("", "", "'[]' ")
    df['node_visited']=[x.translate(sym_list) for x in df['nodes_visited'].tolist()]
    pattern = re.compile(",")
    df['node_visited']=df['node_visited'].apply(lambda x:pattern.split(x))
    for idx, element in enumerate(df['node_visited']):
        nodes_name = list(map(lambda x: list(nodes_dict[x])[0] if x in nodes_dict else x, element))
        nodes_type = list(map(lambda x: list(nodes_dict[x])[1] if x in nodes_dict else x, element))
        indice_standard = [i for i, y in enumerate(nodes_type) if y == "standard"]
        if len (element)>2 and (element[-2]=='Handoff' or element[-2]=='More Help'):
            df.loc[idx, 'node_visited'] = element[-2]
        elif len (indice_standard) > 0:
            df.loc[idx, 'node_visited'] = nodes_name[indice_standard[-1]]
        else:
            df.loc[idx, 'node_visited'] = nodes_name[-1]

    return df




def conv_id_dict (df_logs_formated):
    UniqueConv = df_logs_formated.conversation_id.unique()
    ConvDict = {elem : pd.DataFrame for elem in UniqueConv}
    for key in ConvDict.keys():
        ConvDict[key] = df_logs_formated[:][df_logs_formated.conversation_id == key]
    return ConvDict


def extract_dialog_node_name_WA(workspace_nodes):
    """
    Extract more friendly dialog node names from the Watson Assistant workspace
    return a nodes dictionary object.
    """

    nodes_dict = {}
    nodes_type = {}
    for idx,obj in workspace_nodes.iterrows():
        if (obj['type']=='standard') and not (obj['title'] is np.nan or obj['title'] != obj['title']):
            nodes_dict[obj['dialog_node']]=obj['title']
        else:
            nodes_dict[obj['dialog_node']]=obj['dialog_node']
    return nodes_dict


def _extract_dialog_node_name(dialog_nodes):
    nodes_dict = {}
    nodes_type = {}
    for obj in dialog_nodes:
        if (obj['type']=='standard') and ('title' in obj):
            if (obj['title'] is not None):
                nodes_dict[obj['dialog_node']] = (obj['title'],obj['type'])
            else:
                nodes_dict[obj['dialog_node']] = (obj['dialog_node'],obj['type'])
        else:
            nodes_dict[obj['dialog_node']] = (obj['dialog_node'],obj['type'])
    return nodes_dict
