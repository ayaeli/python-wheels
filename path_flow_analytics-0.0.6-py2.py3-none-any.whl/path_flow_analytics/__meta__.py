# Automatically created. Please do not edit.
__version__ = u'0.0.6'
__author__ = u'Lior Turgeman'
