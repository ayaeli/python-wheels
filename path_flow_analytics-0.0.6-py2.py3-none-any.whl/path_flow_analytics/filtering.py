import pandas as pd
import numpy as np

#filter logs by included node
def filter_logs_df_by_included_node(node, df_logs_formated):
    filtered_df_logs = None
    
    UniqueConv = df_logs_formated.conversation_id.unique()
    ConvDict = {elem : pd.DataFrame for elem in UniqueConv}
    for key in ConvDict.keys():
        ConvDict[key] = df_logs_formated[:][df_logs_formated.conversation_id == key]
        
    for i, (k, v) in enumerate(ConvDict.items()):
        dfP1=pd.DataFrame(v, columns=v.columns).sort_values(by=['response_timestamp'])
        if any(dfP1['node_visited'] == node):
            filtered_df_logs = pd.concat([filtered_df_logs,dfP1])
    return filtered_df_logs

## filter conversations starting with initial intent
def filter_logs_df_by_initial_intent(intent, df_logs_formated):
    filtered_df_logs = None
    
    UniqueConv = df_logs_formated.conversation_id.unique()
    ConvDict = {elem : pd.DataFrame for elem in UniqueConv}
    for key in ConvDict.keys():
        ConvDict[key] = df_logs_formated[:][df_logs_formated.conversation_id == key]
    
    for i, (k, v) in enumerate(ConvDict.items()):
        dfP1=pd.DataFrame(v, columns=v.columns).sort_values(by=['response_timestamp'])
        if (dfP1['response_intent'].iloc[0] == intent):
            filtered_df_logs = pd.concat([filtered_df_logs,dfP1])
    return filtered_df_logs

## filtering by truncating conversations from selected node onwards
def filter_logs_df_node_onwards(node, df_logs_formated):
    filtered_df_logs = None
    
    UniqueConv = df_logs_formated.conversation_id.unique()
    ConvDict = {elem : pd.DataFrame for elem in UniqueConv}
    for key in ConvDict.keys():
        ConvDict[key] = df_logs_formated[:][df_logs_formated.conversation_id == key]
    
    for i, (k, v) in enumerate(ConvDict.items()):
        dfP1 = pd.DataFrame(v, columns=v.columns).sort_values(by=['response_timestamp'])
        if any(dfP1['node_visited'] == node):
            dfP1 = dfP1.reset_index()
            dfP1 = dfP1.iloc[dfP1.index[dfP1['node_visited'] == node].tolist()[0]:len(dfP1),:]
            filtered_df_logs = pd.concat([filtered_df_logs,dfP1])
    return filtered_df_logs


## filter by dates
def filter_by_date (df, start_date, end_date):
    mask = (pd.to_datetime(df['Date']) > start_date) & (pd.to_datetime(df['Date']) <= end_date)
    df = df.loc[mask].reset_index()
    return df
