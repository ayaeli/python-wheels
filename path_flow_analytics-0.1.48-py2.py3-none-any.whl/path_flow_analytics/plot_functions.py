import matplotlib
import matplotlib.pyplot as plt

import numpy as np
#######################################################################
# wordcloud
from wordcloud import WordCloud, STOPWORDS, ImageColorGenerator

##################################################################################
# bar plot for two series
def plot_bar2(bar1,bar2,x_label,y_label,xtick_labels,xangle,bar_legend,title):
    
    plt.rcParams['figure.figsize'] = [15, 10]
    #plt.rcParams['figure.figsize'] = [18, 12]
    
    num_bars=len(bar1) 
     
    font = {'weight' : 'bold',
            'size'   : 14}

    plt.rc('font', **font)
    #plt.axis('on')
    
    fig = plt.figure()
    ax = fig.add_subplot(111)
    
    rects1 = ax.bar(np.arange(0.35,num_bars,1),bar1,width=0.3,color='red')
    rects2 = ax.bar(np.arange(0.65,num_bars,1),bar2,width=0.3,color='green')

    plt.xlabel(x_label,fontsize=16)
    plt.ylabel(y_label,fontsize=16)    
     
    plt.xticks(np.arange(0.5,num_bars,1),xtick_labels, rotation=xangle, ha='right')
    #plt.yticks(np.arange(1,6),ytick_labels) 
    
    plt.xlim(0,num_bars)
    #plt.ylim(-0.1,0.05)
     
    #plt.grid(axis='y')
    plt.grid()
    plt.title(title, fontsize=30, position=[0.5, 1.03]) 
    ax.legend( (rects1[0], rects2[0]), bar_legend)
    #plt.tight_layout()
    #plt.savefig('intents.png',transparent=True)
    plt.show()
    #plt.show(block=False)    
    
    return

###############################################################################
# show word clouds
def show_word_cloud(cloud_dict, cloud_title):
    
    cloud_dict_new={}
    # replace spaces by underscore
    for key in cloud_dict:
        key1 = key.replace(" ", "_")
        cloud_dict_new[key1]=cloud_dict[key]       
    
    cloud = WordCloud(stopwords=STOPWORDS, collocations = False, relative_scaling=1, 
                          #max_words=30,  
                          background_color='lightgrey', prefer_horizontal=1, width=1200, height=1200
                         ).generate_from_frequencies(cloud_dict_new,max_font_size=144)
 
    plt.rcParams['figure.figsize'] = [15, 10]
    plt.imshow(cloud, interpolation='bilinear')
    plt.title(cloud_title, fontsize=30, position=[0.5, 1.03]) 
    plt.axis('off')
    plt.show()
    
    return
    
###############################################################################
# show two word clouds side by side
def show_word_cloud2(cloud_dict1,cloud_title1,cloud_dict2,cloud_title2):
    
    cloud_dict_new1={}
    cloud_dict_new2={}
    
    # replace spaces by underscore
    for key in cloud_dict1:
        key1 = key.replace(" ", "_")
        cloud_dict_new1[key1]=cloud_dict1[key]       
    
    # replace spaces by underscore
    for key in cloud_dict2:
        key2 = key.replace(" ", "_")
        cloud_dict_new2[key2]=cloud_dict2[key] 
    
    cloud1 = WordCloud(stopwords=STOPWORDS, collocations = False, relative_scaling=1, 
                          #max_words=30,  
                          background_color='lightgrey', prefer_horizontal=1, width=1200, height=1200
                         ).generate_from_frequencies(cloud_dict_new1,max_font_size=144)
    
    cloud2 = WordCloud(stopwords=STOPWORDS, collocations = False, relative_scaling=1, 
                          #max_words=30,  
                          background_color='lightgrey', prefer_horizontal=1, width=1200, height=1200
                         ).generate_from_frequencies(cloud_dict_new2,max_font_size=144)
    
    plt.rcParams['figure.figsize'] = [14, 7]                    
    fig = plt.figure() 
    ax1 = fig.add_subplot(1,2,1)
    ax1.set_title(cloud_title1, size=20,  position=[0.5, 1.03]) # Title 
    ax1.imshow(cloud1)
    ax1.axis('off')
    ax2 = fig.add_subplot(1,2,2)
    ax2.set_title(cloud_title2, size=20,  position=[0.5, 1.03]) # Title 
    ax2.imshow(cloud2)
    ax2.axis('off')
    #     plt.imshow(cloud, interpolation='bilinear')
    return

##################################################################################
# bar plot for two series
def plot_frequencies(df_frequencies):
    
    bar1 = df_frequencies["Failure keywords: negative corpus frequencies, %"]
    bar2 = df_frequencies["Failure keywords: positive corpus frequencies, %"]
    bar3 = df_frequencies["Success keywords: negative corpus frequencies, %"]
    bar4 = df_frequencies["Success keywords: positive corpus frequencies, %"]
    
    tick_labels1=df_frequencies["Failure keywords"]
    tick_labels2=df_frequencies["Success keywords"]
    
    x_label="keywords"
    y_label="frequency"
    
    bar_legend = ['failure corpus', 'success corpus']
    
    #plt.rcParams['figure.figsize'] = [15, 10]
    plt.rcParams['figure.figsize'] = [16, 6]  
    
    num_bars=len(df_frequencies) 
     
#     font = {'weight' : 'bold',
#             'size'   : 14}
#     
#     plt.rc('font', **font)
    #plt.axis('on')  
                 
    fig = plt.figure() 
    ax1 = fig.add_subplot(1,2,1)
    ax1.set_title("Failure Keywords", size=20,  position=[0.5, 1.03]) # Title 
    ax1.set_xlabel(x_label,fontsize=14)
    ax1.set_ylabel(y_label,fontsize=14)  
    ax1.set_xticks(np.arange(0.5,num_bars,1)) 
    ax1.set_xticklabels(tick_labels1,fontsize=10,rotation=20,ha='right')
    ax1.set_xlim(0,num_bars)
    rects1 = ax1.bar(np.arange(0.35,num_bars,1),bar1,width=0.3,color='red')
    rects2 = ax1.bar(np.arange(0.65,num_bars,1),bar2,width=0.3,color='green')
    ax1.legend( (rects1[0], rects2[0]), bar_legend) 
    plt.grid()
    
    ax2 = fig.add_subplot(1,2,2)
    ax2.set_title("Success Keywords", size=20,  position=[0.5, 1.03]) # Title 
    ax2.set_xlabel(x_label,fontsize=14)
    ax2.set_ylabel(y_label,fontsize=14)
    ax2.set_xticks(np.arange(0.5,num_bars,1)) 
    ax2.set_xticklabels(tick_labels2, fontsize=10, rotation=20, ha='right')
    ax2.set_xlim(0,num_bars)
    rects3 = ax2.bar(np.arange(0.35,num_bars,1),bar3,width=0.3,color='red')
    rects4 = ax2.bar(np.arange(0.65,num_bars,1),bar4,width=0.3,color='green')
    ax2.legend( (rects3[0], rects4[0]), bar_legend) 
 
    
    #plt.xlim(0,num_bars)
    #plt.ylim(-0.1,0.05)
     
    plt.grid()
#     plt.grid()
 
#     ax.legend( (rects1[0], rects2[0]), bar_legend)
 
    plt.show()
    #plt.show(block=False)    
    
    return 