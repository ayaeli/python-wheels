# Automatically created. Please do not edit.
__version__ = u'0.1.48'

__author__ = u'Avi Yaeli'
